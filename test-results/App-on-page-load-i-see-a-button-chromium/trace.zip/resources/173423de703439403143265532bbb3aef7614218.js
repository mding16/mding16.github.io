import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0a4e3deb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import { ModeStatus } from "/src/components/StatusComponents/ModeStatus.tsx";
import { LoadStatus } from "/src/components/StatusComponents/LoadStatus.tsx";
import { DataTable } from "/src/components/MiscComponents/DataTable.tsx";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=0a4e3deb"; const useState = __vite__cjsImport7_react["useState"];
import { ControlledInput } from "/src/components/MiscComponents/ControlledInput.tsx";
import { filepathToParsedCSVMap, queryToSearchedCSVMap } from "/src/components/Mock/mockedJson.ts";
const searchLength = 7;
const loadLength = 10;
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [dataLoaded, setDataLoaded] = useState(0);
  const [data, setData] = useState();
  const [csvFilePath, setFilePath] = useState("");
  const [briefmode, setMode] = useState(true);
  function handleSubmit(commandString2) {
    {
    }
    if (commandString2 === "mode") {
      setMode(!briefmode);
      {
      }
    } else if (commandString2.length >= loadLength && commandString2.substring(0, loadLength) === "load_file ") {
      var filePath = commandString2.substring(loadLength, commandString2.length);
      if (filepathToParsedCSVMap.has(filePath)) {
        setData(filepathToParsedCSVMap.get(filePath));
        setDataLoaded(1);
        setFilePath(filePath);
        load_csv_success(props, briefmode, commandString2);
      } else {
        load_csv_fail(props, briefmode, commandString2);
      }
      {
      }
    } else if (commandString2 === "view" && dataLoaded === 0) {
      view_fail(props, briefmode, commandString2);
    } else if (commandString2 === "view" && dataLoaded === 1) {
      view_success(props, commandString2, briefmode, data);
      {
      }
    } else if (commandString2.length >= searchLength && commandString2.substring(0, searchLength) === "search " && dataLoaded === 0) {
      search_not_loaded(props, briefmode, commandString2);
    } else if (commandString2.length >= searchLength && commandString2.substring(0, searchLength) === "search " && dataLoaded === 1) {
      search_loaded(props, briefmode, commandString2);
    } else {
      error_message(props, briefmode, commandString2);
    }
    {
    }
    setCount(count + 1);
    setCommandString("");
  }
  {
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "container", children: [
      /* @__PURE__ */ jsxDEV(ModeStatus, { mode: briefmode }, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 73,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(LoadStatus, { loadStatus: dataLoaded, csvFile: csvFilePath }, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 74,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 71,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container1", children: /* @__PURE__ */ jsxDEV("div", { className: "history", children: "COMMANDS" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 77,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 76,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container2", children: [
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: /* @__PURE__ */ jsxDEV("div", { className: "buttontext", children: [
        "Submitted ",
        count,
        " time(s)"
      ] }, void 0, true, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 87,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 86,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 81,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
    lineNumber: 70,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "qqh86pXp8iNB55NFdhkPaaPiG/g=");
_c = REPLInput;
function load_csv_success(props, briefmode, command) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "success", children: "successfully loaded CSV" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 96,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 98,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "success", children: "Output: successfully loaded csv" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 98,
      columnNumber: 94
    }, this)]);
  }
}
function load_csv_fail(props, briefmode, command) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "failed to load csv" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 103,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 105,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Output: failed to load csv" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 105,
      columnNumber: 94
    }, this)]);
  }
}
function view_fail(props, briefmode, command) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "data not loaded" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 110,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 112,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Output: data not loaded" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 112,
      columnNumber: 94
    }, this)]);
  }
}
function view_success(props, command, briefmode, data) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV(DataTable, { data }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 117,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 119,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "success", children: "Output:" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 119,
      columnNumber: 94
    }, this), /* @__PURE__ */ jsxDEV(DataTable, { data }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 119,
      columnNumber: 136
    }, this)]);
  }
}
function error_message(props, briefmode, command) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "invalid command or arguments" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 124,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 126,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Output: invalid command or arguments" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 126,
      columnNumber: 94
    }, this)]);
  }
}
function search_not_loaded(props, briefmode, command) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "data not loaded" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 131,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 133,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Output: data not loaded" }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 133,
      columnNumber: 94
    }, this)]);
  }
}
function search_loaded(props, briefmode, command) {
  var searchString = command.substring(searchLength, command.length);
  var validArguments = command.substring(searchLength, command.length).includes(" ");
  var searchValid = queryToSearchedCSVMap.has(searchString);
  if (validArguments) {
    if (searchValid) {
      if (briefmode) {
        var data = queryToSearchedCSVMap.get(searchString);
        props.setHistory([...props.history, /* @__PURE__ */ jsxDEV(DataTable, { data }, void 0, false, {
          fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 144,
          columnNumber: 45
        }, this)]);
      }
      if (!briefmode) {
        var data = queryToSearchedCSVMap.get(searchString);
        props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
          "Command: ",
          command
        ] }, void 0, true, {
          fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 148,
          columnNumber: 45
        }, this), /* @__PURE__ */ jsxDEV("div", { className: "success", children: "Output:" }, void 0, false, {
          fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 148,
          columnNumber: 98
        }, this), /* @__PURE__ */ jsxDEV(DataTable, { data }, void 0, false, {
          fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 148,
          columnNumber: 140
        }, this)]);
      }
    }
    if (!searchValid) {
      if (briefmode) {
        props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "query not found in given column" }, void 0, false, {
          fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 153,
          columnNumber: 45
        }, this)]);
      }
      if (!briefmode) {
        props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
          "Command: ",
          command
        ] }, void 0, true, {
          fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 156,
          columnNumber: 45
        }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Output: query not found in given column" }, void 0, false, {
          fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 156,
          columnNumber: 98
        }, this)]);
      }
    }
  }
  if (!validArguments) {
    if (briefmode) {
      props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "invalid number of arguments" }, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 164,
        columnNumber: 43
      }, this)]);
    }
    if (!briefmode) {
      props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
        "Command: ",
        command
      ] }, void 0, true, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 167,
        columnNumber: 43
      }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Output: invalid number of arguments" }, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 167,
        columnNumber: 96
      }, this)]);
    }
  }
}
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUdROzs7Ozs7Ozs7Ozs7Ozs7OztBQWpHUixPQUFPO0FBQ1AsU0FBU0Esa0JBQWtCO0FBQzNCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBbUNDLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FDRUMsd0JBQ0FDLDZCQUNLO0FBWVAsTUFBTUMsZUFBZTtBQUNyQixNQUFNQyxhQUFhO0FBRVosZ0JBQVNDLFVBQVVDLE9BQXVCO0FBQUFDLEtBQUE7QUFDL0MsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSVYsU0FBaUIsRUFBRTtBQUM3RCxRQUFNLENBQUNXLE9BQU9DLFFBQVEsSUFBSVosU0FBaUIsQ0FBQztBQUM1QyxRQUFNLENBQUNhLFlBQVlDLGFBQWEsSUFBSWQsU0FBaUIsQ0FBQztBQUN0RCxRQUFNLENBQUNlLE1BQU1DLE9BQU8sSUFBSWhCLFNBQWlDO0FBQ3pELFFBQU0sQ0FBQ2lCLGFBQWFDLFdBQVcsSUFBSWxCLFNBQWlCLEVBQUU7QUFDdEQsUUFBTSxDQUFDbUIsV0FBV0MsT0FBTyxJQUFJcEIsU0FBa0IsSUFBSTtBQUVuRCxXQUFTcUIsYUFBYVosZ0JBQXVCO0FBQzNDO0FBQUEsSUFDRTtBQUVGLFFBQUlBLG1CQUFrQixRQUFRO0FBQzVCVyxjQUFRLENBQUNELFNBQVM7QUFFbEI7QUFBQSxNQUNFO0FBQUEsSUFFSixXQUNFVixlQUFjYSxVQUFVakIsY0FDeEJJLGVBQWNjLFVBQVUsR0FBR2xCLFVBQVUsTUFBTSxjQUMzQztBQUNBLFVBQUltQixXQUFXZixlQUFjYyxVQUFVbEIsWUFBWUksZUFBY2EsTUFBTTtBQUN2RSxVQUFJcEIsdUJBQXVCdUIsSUFBSUQsUUFBUSxHQUFHO0FBQ3hDUixnQkFBUWQsdUJBQXVCd0IsSUFBSUYsUUFBUSxDQUFDO0FBQzVDVixzQkFBYyxDQUFDO0FBQ2ZJLG9CQUFZTSxRQUFRO0FBQ3BCRyx5QkFBaUJwQixPQUFPWSxXQUFXVixjQUFhO0FBQUEsTUFDbEQsT0FBTztBQUNMbUIsc0JBQWNyQixPQUFPWSxXQUFXVixjQUFhO0FBQUEsTUFDL0M7QUFFQTtBQUFBLE1BQ0U7QUFBQSxJQUVKLFdBQVdBLG1CQUFrQixVQUFVSSxlQUFlLEdBQUc7QUFDdkRnQixnQkFBVXRCLE9BQU9ZLFdBQVdWLGNBQWE7QUFBQSxJQUMzQyxXQUFXQSxtQkFBa0IsVUFBVUksZUFBZSxHQUFHO0FBQ3ZEaUIsbUJBQWF2QixPQUFPRSxnQkFBZVUsV0FBV0osSUFBSTtBQUVsRDtBQUFBLE1BQ0U7QUFBQSxJQUVKLFdBQ0VOLGVBQWNhLFVBQVVsQixnQkFDeEJLLGVBQWNjLFVBQVUsR0FBR25CLFlBQVksTUFBTSxhQUM3Q1MsZUFBZSxHQUNmO0FBQ0FrQix3QkFBa0J4QixPQUFPWSxXQUFXVixjQUFhO0FBQUEsSUFDbkQsV0FDRUEsZUFBY2EsVUFBVWxCLGdCQUN4QkssZUFBY2MsVUFBVSxHQUFHbkIsWUFBWSxNQUFNLGFBQzdDUyxlQUFlLEdBQ2Y7QUFDQW1CLG9CQUFjekIsT0FBT1ksV0FBV1YsY0FBYTtBQUFBLElBQy9DLE9BQU87QUFDTHdCLG9CQUFjMUIsT0FBT1ksV0FBV1YsY0FBYTtBQUFBLElBQy9DO0FBRUE7QUFBQSxJQUNFO0FBRUZHLGFBQVNELFFBQVEsQ0FBQztBQUNsQkQscUJBQWlCLEVBQUU7QUFBQSxFQUNyQjtBQUVBO0FBQUEsRUFDRTtBQUVGLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsYUFFYjtBQUFBLDZCQUFDLGNBQVcsTUFBTVMsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QjtBQUFBLE1BQzdCLHVCQUFDLGNBQVcsWUFBWU4sWUFBWSxTQUFTSSxlQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsU0FINUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxTQUFJLFdBQVUsV0FBVSx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQyxLQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsbUJBQ0MsT0FBT1IsZUFDUCxVQUFVQyxrQkFDVixXQUFXLG1CQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHNkI7QUFBQSxNQUU3Qix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBSTtBQUFBLE1BR0osdUJBQUMsWUFBTyxTQUFTLE1BQU1XLGFBQWFaLGFBQWEsR0FDL0MsaUNBQUMsU0FBSSxXQUFVLGNBQWE7QUFBQTtBQUFBLFFBQVdFO0FBQUFBLFFBQU07QUFBQSxXQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFELEtBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsT0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQTtBQUVKO0FBQUNILEdBaEdlRixXQUFTO0FBQUE0QixLQUFUNUI7QUFrR2hCLFNBQVNxQixpQkFDUHBCLE9BQ0FZLFdBQ0FnQixTQUNBO0FBQ0EsTUFBSWhCLFdBQVc7QUFDYlosVUFBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFXLFdBQVcsdUNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0QsQ0FBTSxDQUN6RDtBQUFBLEVBQ0gsT0FBTztBQUNMOUIsVUFBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFXLFdBQVc7QUFBQTtBQUFBLE1BQVVGO0FBQUFBLFNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkMsR0FDN0MsdUJBQUMsU0FBSSxXQUFXLFdBQVcsK0NBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEQsQ0FBTSxDQUNqRTtBQUFBLEVBQ0g7QUFDRjtBQUVBLFNBQVNQLGNBQ1ByQixPQUNBWSxXQUNBZ0IsU0FDQTtBQUNBLE1BQUloQixXQUFXO0FBQ2JaLFVBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLFNBQUksV0FBVyxTQUFTLGtDQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJDLENBQU0sQ0FDbEQ7QUFBQSxFQUNILE9BQU87QUFDTDlCLFVBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLFNBQUksV0FBVyxXQUFXO0FBQUE7QUFBQSxNQUFVRjtBQUFBQSxTQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZDLEdBQzdDLHVCQUFDLFNBQUksV0FBVyxTQUFTLDBDQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1ELENBQU0sQ0FDMUQ7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxTQUFTTixVQUFVdEIsT0FBdUJZLFdBQW9CZ0IsU0FBaUI7QUFDN0UsTUFBSWhCLFdBQVc7QUFDYlosVUFBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFXLFNBQVMsK0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0MsQ0FBTSxDQUMvQztBQUFBLEVBQ0gsT0FBTztBQUNMOUIsVUFBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFXLFdBQVc7QUFBQTtBQUFBLE1BQVVGO0FBQUFBLFNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkMsR0FDN0MsdUJBQUMsU0FBSSxXQUFXLFNBQVMsdUNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0QsQ0FBTSxDQUN2RDtBQUFBLEVBQ0g7QUFDRjtBQUVBLFNBQVNMLGFBQ1B2QixPQUNBNEIsU0FDQWhCLFdBQ0FKLE1BQ0E7QUFDQSxNQUFJSSxXQUFXO0FBQ2JaLFVBQU02QixXQUFXLENBQUMsR0FBRzdCLE1BQU04QixTQUFTLHVCQUFDLGFBQVUsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVCLENBQVksQ0FBQztBQUFBLEVBQzFFLE9BQU87QUFDTDlCLFVBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLFNBQUksV0FBVyxXQUFXO0FBQUE7QUFBQSxNQUFVRjtBQUFBQSxTQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZDLEdBQzdDLHVCQUFDLFNBQUksV0FBVyxXQUFXLHVCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtDLEdBQ2xDLHVCQUFDLGFBQVUsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVCLENBQVksQ0FDcEM7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxTQUFTRixjQUNQMUIsT0FDQVksV0FDQWdCLFNBQ0E7QUFDQSxNQUFJaEIsV0FBVztBQUNiWixVQUFNNkIsV0FBVyxDQUNmLEdBQUc3QixNQUFNOEIsU0FDVCx1QkFBQyxTQUFJLFdBQVcsU0FBUyw0Q0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRCxDQUFNLENBQzVEO0FBQUEsRUFDSCxPQUFPO0FBQ0w5QixVQUFNNkIsV0FBVyxDQUNmLEdBQUc3QixNQUFNOEIsU0FDVCx1QkFBQyxTQUFJLFdBQVcsV0FBVztBQUFBO0FBQUEsTUFBVUY7QUFBQUEsU0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QyxHQUM3Qyx1QkFBQyxTQUFJLFdBQVcsU0FBUyxvREFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RCxDQUFNLENBQ3BFO0FBQUEsRUFDSDtBQUNGO0FBRUEsU0FBU0osa0JBQ1B4QixPQUNBWSxXQUNBZ0IsU0FDQTtBQUNBLE1BQUloQixXQUFXO0FBQ2JaLFVBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLFNBQUksV0FBVyxTQUFTLCtCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdDLENBQU0sQ0FDL0M7QUFBQSxFQUNILE9BQU87QUFDTDlCLFVBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLFNBQUksV0FBVyxXQUFXO0FBQUE7QUFBQSxNQUFVRjtBQUFBQSxTQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZDLEdBQzdDLHVCQUFDLFNBQUksV0FBVyxTQUFTLHVDQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdELENBQU0sQ0FDdkQ7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxTQUFTSCxjQUNQekIsT0FDQVksV0FDQWdCLFNBQ0E7QUFDQSxNQUFJRyxlQUFlSCxRQUFRWixVQUFVbkIsY0FBYytCLFFBQVFiLE1BQU07QUFDakUsTUFBSWlCLGlCQUFpQkosUUFDbEJaLFVBQVVuQixjQUFjK0IsUUFBUWIsTUFBTSxFQUN0Q2tCLFNBQVMsR0FBRztBQUNmLE1BQUlDLGNBQWN0QyxzQkFBc0JzQixJQUFJYSxZQUFZO0FBRXhELE1BQUlDLGdCQUFnQjtBQUNsQixRQUFJRSxhQUFhO0FBQ2YsVUFBSXRCLFdBQVc7QUFDYixZQUFJSixPQUFPWixzQkFBc0J1QixJQUFJWSxZQUFZO0FBQ2pEL0IsY0FBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsYUFBVSxRQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUIsQ0FBWSxDQUNwQztBQUFBLE1BQ0g7QUFFQSxVQUFJLENBQUNsQixXQUFXO0FBQ2QsWUFBSUosT0FBT1osc0JBQXNCdUIsSUFBSVksWUFBWTtBQUNqRC9CLGNBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLFNBQUksV0FBVyxXQUFXO0FBQUE7QUFBQSxVQUFVRjtBQUFBQSxhQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDLEdBQzdDLHVCQUFDLFNBQUksV0FBVyxXQUFXLHVCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDLEdBQ2xDLHVCQUFDLGFBQVUsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCLENBQVksQ0FDcEM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUVBLFFBQUksQ0FBQ00sYUFBYTtBQUNoQixVQUFJdEIsV0FBVztBQUNiWixjQUFNNkIsV0FBVyxDQUNmLEdBQUc3QixNQUFNOEIsU0FDVCx1QkFBQyxTQUFJLFdBQVcsU0FBUywrQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RCxDQUFNLENBQy9EO0FBQUEsTUFDSDtBQUVBLFVBQUksQ0FBQ2xCLFdBQVc7QUFDZFosY0FBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFXLFdBQVc7QUFBQTtBQUFBLFVBQVVGO0FBQUFBLGFBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkMsR0FDN0MsdUJBQUMsU0FBSSxXQUFXLFNBQVEsdURBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxDQUFNLENBQ1A7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxNQUFJLENBQUNJLGdCQUFnQjtBQUNuQixRQUFJcEIsV0FBVztBQUNiWixZQUFNNkIsV0FBVyxDQUNmLEdBQUc3QixNQUFNOEIsU0FDVCx1QkFBQyxTQUFJLFdBQVcsU0FBUywyQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRCxDQUFNLENBQzNEO0FBQUEsSUFDSDtBQUVBLFFBQUksQ0FBQ2xCLFdBQVc7QUFDZFosWUFBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFXLFdBQVc7QUFBQTtBQUFBLFFBQVVGO0FBQUFBLFdBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkMsR0FDN0MsdUJBQUMsU0FBSSxXQUFXLFNBQVMsbURBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEQsQ0FBTSxDQUNuRTtBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0Y7QUFBQyxJQUFBRDtBQUFBUSxhQUFBUixJQUFBIiwibmFtZXMiOlsiTW9kZVN0YXR1cyIsIkxvYWRTdGF0dXMiLCJEYXRhVGFibGUiLCJ1c2VTdGF0ZSIsIkNvbnRyb2xsZWRJbnB1dCIsImZpbGVwYXRoVG9QYXJzZWRDU1ZNYXAiLCJxdWVyeVRvU2VhcmNoZWRDU1ZNYXAiLCJzZWFyY2hMZW5ndGgiLCJsb2FkTGVuZ3RoIiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiY291bnQiLCJzZXRDb3VudCIsImRhdGFMb2FkZWQiLCJzZXREYXRhTG9hZGVkIiwiZGF0YSIsInNldERhdGEiLCJjc3ZGaWxlUGF0aCIsInNldEZpbGVQYXRoIiwiYnJpZWZtb2RlIiwic2V0TW9kZSIsImhhbmRsZVN1Ym1pdCIsImxlbmd0aCIsInN1YnN0cmluZyIsImZpbGVQYXRoIiwiaGFzIiwiZ2V0IiwibG9hZF9jc3Zfc3VjY2VzcyIsImxvYWRfY3N2X2ZhaWwiLCJ2aWV3X2ZhaWwiLCJ2aWV3X3N1Y2Nlc3MiLCJzZWFyY2hfbm90X2xvYWRlZCIsInNlYXJjaF9sb2FkZWQiLCJlcnJvcl9tZXNzYWdlIiwiX2MiLCJjb21tYW5kIiwic2V0SGlzdG9yeSIsImhpc3RvcnkiLCJzZWFyY2hTdHJpbmciLCJ2YWxpZEFyZ3VtZW50cyIsImluY2x1ZGVzIiwic2VhcmNoVmFsaWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgTW9kZVN0YXR1cyB9IGZyb20gXCIuL1N0YXR1c0NvbXBvbmVudHMvTW9kZVN0YXR1c1wiO1xuaW1wb3J0IHsgTG9hZFN0YXR1cyB9IGZyb20gXCIuL1N0YXR1c0NvbXBvbmVudHMvTG9hZFN0YXR1c1wiO1xuaW1wb3J0IHsgRGF0YVRhYmxlIH0gZnJvbSBcIi4vTWlzY0NvbXBvbmVudHMvRGF0YVRhYmxlXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9NaXNjQ29tcG9uZW50cy9Db250cm9sbGVkSW5wdXRcIjtcbmltcG9ydCB7XG4gIGZpbGVwYXRoVG9QYXJzZWRDU1ZNYXAsXG4gIHF1ZXJ5VG9TZWFyY2hlZENTVk1hcCxcbn0gZnJvbSBcIi4vTW9jay9tb2NrZWRKc29uXCI7XG5pbXBvcnQgeyB1bnN0YWJsZV9yZW5kZXJTdWJ0cmVlSW50b0NvbnRhaW5lciB9IGZyb20gXCJyZWFjdC1kb21cIjtcbmltcG9ydCB7XG4gIGdldFBhcnNlZENvbW1hbmRMaW5lT2ZDb25maWdGaWxlLFxuICBpc0pTRG9jQ29tbWVudENvbnRhaW5pbmdOb2RlLFxufSBmcm9tIFwidHlwZXNjcmlwdFwiO1xuXG5pbnRlcmZhY2UgUkVQTElucHV0UHJvcHMge1xuICBoaXN0b3J5OiBKU1guRWxlbWVudFtdO1xuICBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxKU1guRWxlbWVudFtdPj47XG59XG5cbmNvbnN0IHNlYXJjaExlbmd0aCA9IDc7XG5jb25zdCBsb2FkTGVuZ3RoID0gMTA7XG5cbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHM6IFJFUExJbnB1dFByb3BzKSB7XG4gIGNvbnN0IFtjb21tYW5kU3RyaW5nLCBzZXRDb21tYW5kU3RyaW5nXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIGNvbnN0IFtjb3VudCwgc2V0Q291bnRdID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcbiAgY29uc3QgW2RhdGFMb2FkZWQsIHNldERhdGFMb2FkZWRdID0gdXNlU3RhdGU8bnVtYmVyPigwKTsgLy8gMCBpcyBkYXRhIG5vdCBsb2FkZWQsIDEgaXMgZGF0YSBsb2FkZWRcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGU8c3RyaW5nW11bXSB8IHVuZGVmaW5lZD4oKTsgLy8gY2FsbCBzZXREYXRhIGluIGxvYWRjc3YsIGNhbGwgZGF0YSBpbiB2aWV3L3NlYXJjaFxuICBjb25zdCBbY3N2RmlsZVBhdGgsIHNldEZpbGVQYXRoXSA9IHVzZVN0YXRlPFN0cmluZz4oXCJcIik7IC8vIHVzZWQgZm9yIGFjY2Vzc2luZyBvdXIgbW9jayBkYXRhIG1hcCdzIFwiQ1NWc1wiXG4gIGNvbnN0IFticmllZm1vZGUsIHNldE1vZGVdID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSk7XG5cbiAgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmc6IHN0cmluZykge1xuICAgIHtcbiAgICAgIC8qIEhBTkRMSU5HIENPTU1BTkQ6IG1vZGUgKi9cbiAgICB9XG4gICAgaWYgKGNvbW1hbmRTdHJpbmcgPT09IFwibW9kZVwiKSB7XG4gICAgICBzZXRNb2RlKCFicmllZm1vZGUpO1xuXG4gICAgICB7XG4gICAgICAgIC8qIEhBTkRMSU5HIENPTU1BTkQ6IGxvYWRfZmlsZSAqL1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoXG4gICAgICBjb21tYW5kU3RyaW5nLmxlbmd0aCA+PSBsb2FkTGVuZ3RoICYmXG4gICAgICBjb21tYW5kU3RyaW5nLnN1YnN0cmluZygwLCBsb2FkTGVuZ3RoKSA9PT0gXCJsb2FkX2ZpbGUgXCJcbiAgICApIHtcbiAgICAgIHZhciBmaWxlUGF0aCA9IGNvbW1hbmRTdHJpbmcuc3Vic3RyaW5nKGxvYWRMZW5ndGgsIGNvbW1hbmRTdHJpbmcubGVuZ3RoKTtcbiAgICAgIGlmIChmaWxlcGF0aFRvUGFyc2VkQ1NWTWFwLmhhcyhmaWxlUGF0aCkpIHtcbiAgICAgICAgc2V0RGF0YShmaWxlcGF0aFRvUGFyc2VkQ1NWTWFwLmdldChmaWxlUGF0aCkpO1xuICAgICAgICBzZXREYXRhTG9hZGVkKDEpO1xuICAgICAgICBzZXRGaWxlUGF0aChmaWxlUGF0aCk7XG4gICAgICAgIGxvYWRfY3N2X3N1Y2Nlc3MocHJvcHMsIGJyaWVmbW9kZSwgY29tbWFuZFN0cmluZyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsb2FkX2Nzdl9mYWlsKHByb3BzLCBicmllZm1vZGUsIGNvbW1hbmRTdHJpbmcpO1xuICAgICAgfVxuXG4gICAgICB7XG4gICAgICAgIC8qIEhBTkRMSU5HIENPTU1BTkQ6IHZpZXcgKi9cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNvbW1hbmRTdHJpbmcgPT09IFwidmlld1wiICYmIGRhdGFMb2FkZWQgPT09IDApIHtcbiAgICAgIHZpZXdfZmFpbChwcm9wcywgYnJpZWZtb2RlLCBjb21tYW5kU3RyaW5nKTtcbiAgICB9IGVsc2UgaWYgKGNvbW1hbmRTdHJpbmcgPT09IFwidmlld1wiICYmIGRhdGFMb2FkZWQgPT09IDEpIHtcbiAgICAgIHZpZXdfc3VjY2Vzcyhwcm9wcywgY29tbWFuZFN0cmluZywgYnJpZWZtb2RlLCBkYXRhKTtcblxuICAgICAge1xuICAgICAgICAvKiBIQU5ETElORyBDT01NQU5EOiBzZWFyY2ggKi9cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKFxuICAgICAgY29tbWFuZFN0cmluZy5sZW5ndGggPj0gc2VhcmNoTGVuZ3RoICYmXG4gICAgICBjb21tYW5kU3RyaW5nLnN1YnN0cmluZygwLCBzZWFyY2hMZW5ndGgpID09PSBcInNlYXJjaCBcIiAmJlxuICAgICAgZGF0YUxvYWRlZCA9PT0gMFxuICAgICkge1xuICAgICAgc2VhcmNoX25vdF9sb2FkZWQocHJvcHMsIGJyaWVmbW9kZSwgY29tbWFuZFN0cmluZyk7XG4gICAgfSBlbHNlIGlmIChcbiAgICAgIGNvbW1hbmRTdHJpbmcubGVuZ3RoID49IHNlYXJjaExlbmd0aCAmJlxuICAgICAgY29tbWFuZFN0cmluZy5zdWJzdHJpbmcoMCwgc2VhcmNoTGVuZ3RoKSA9PT0gXCJzZWFyY2ggXCIgJiZcbiAgICAgIGRhdGFMb2FkZWQgPT09IDFcbiAgICApIHtcbiAgICAgIHNlYXJjaF9sb2FkZWQocHJvcHMsIGJyaWVmbW9kZSwgY29tbWFuZFN0cmluZyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGVycm9yX21lc3NhZ2UocHJvcHMsIGJyaWVmbW9kZSwgY29tbWFuZFN0cmluZyk7XG4gICAgfVxuXG4gICAge1xuICAgICAgLyogVXBkYXRpbmcgU3VibWl0IEJ1dHRvbiAqL1xuICAgIH1cbiAgICBzZXRDb3VudChjb3VudCArIDEpO1xuICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XG4gIH1cblxuICB7XG4gICAgLyogUkVUVVJOSU5HIFJFUEwgSU5QVVQgT1VUUFVUICovXG4gIH1cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaW5wdXRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgIHsvKiBNT0RFIFNUQVRVUyAmIERBVEEgTE9BRCBTVEFUVVMgQkFSUyAqL31cbiAgICAgICAgPE1vZGVTdGF0dXMgbW9kZT17YnJpZWZtb2RlfT48L01vZGVTdGF0dXM+XG4gICAgICAgIDxMb2FkU3RhdHVzIGxvYWRTdGF0dXM9e2RhdGFMb2FkZWR9IGNzdkZpbGU9e2NzdkZpbGVQYXRofT48L0xvYWRTdGF0dXM+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyMVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpc3RvcnlcIj5DT01NQU5EUzwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBDT01NQU5EIElOUFVUIEJBUiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyMlwiPlxuICAgICAgICA8Q29udHJvbGxlZElucHV0XG4gICAgICAgICAgdmFsdWU9e2NvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgc2V0VmFsdWU9e3NldENvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgYXJpYUxhYmVsPXtcIkNvbW1hbmQgaW5wdXRcIn1cbiAgICAgICAgLz5cbiAgICAgICAgPGJyPjwvYnI+XG5cbiAgICAgICAgey8qIFNVQk1JVCBCVVRUT04gKi99XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmcpfT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ1dHRvbnRleHRcIj5TdWJtaXR0ZWQge2NvdW50fSB0aW1lKHMpPC9kaXY+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIGxvYWRfY3N2X3N1Y2Nlc3MoXG4gIHByb3BzOiBSRVBMSW5wdXRQcm9wcyxcbiAgYnJpZWZtb2RlOiBib29sZWFuLFxuICBjb21tYW5kOiBzdHJpbmdcbikge1xuICBpZiAoYnJpZWZtb2RlKSB7XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAuLi5wcm9wcy5oaXN0b3J5LFxuICAgICAgPGRpdiBjbGFzc05hbWU9e1wic3VjY2Vzc1wifT5zdWNjZXNzZnVsbHkgbG9hZGVkIENTVjwvZGl2PixcbiAgICBdKTtcbiAgfSBlbHNlIHtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJjb21tYW5kXCJ9PkNvbW1hbmQ6IHtjb21tYW5kfTwvZGl2PixcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtcInN1Y2Nlc3NcIn0+T3V0cHV0OiBzdWNjZXNzZnVsbHkgbG9hZGVkIGNzdjwvZGl2PixcbiAgICBdKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBsb2FkX2Nzdl9mYWlsKFxuICBwcm9wczogUkVQTElucHV0UHJvcHMsXG4gIGJyaWVmbW9kZTogYm9vbGVhbixcbiAgY29tbWFuZDogc3RyaW5nXG4pIHtcbiAgaWYgKGJyaWVmbW9kZSkge1xuICAgIHByb3BzLnNldEhpc3RvcnkoW1xuICAgICAgLi4ucHJvcHMuaGlzdG9yeSxcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtcImVycm9yXCJ9PmZhaWxlZCB0byBsb2FkIGNzdjwvZGl2PixcbiAgICBdKTtcbiAgfSBlbHNlIHtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJjb21tYW5kXCJ9PkNvbW1hbmQ6IHtjb21tYW5kfTwvZGl2PixcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtcImVycm9yXCJ9Pk91dHB1dDogZmFpbGVkIHRvIGxvYWQgY3N2PC9kaXY+LFxuICAgIF0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIHZpZXdfZmFpbChwcm9wczogUkVQTElucHV0UHJvcHMsIGJyaWVmbW9kZTogYm9vbGVhbiwgY29tbWFuZDogc3RyaW5nKSB7XG4gIGlmIChicmllZm1vZGUpIHtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5kYXRhIG5vdCBsb2FkZWQ8L2Rpdj4sXG4gICAgXSk7XG4gIH0gZWxzZSB7XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAuLi5wcm9wcy5oaXN0b3J5LFxuICAgICAgPGRpdiBjbGFzc05hbWU9e1wiY29tbWFuZFwifT5Db21tYW5kOiB7Y29tbWFuZH08L2Rpdj4sXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5PdXRwdXQ6IGRhdGEgbm90IGxvYWRlZDwvZGl2PixcbiAgICBdKTtcbiAgfVxufVxuXG5mdW5jdGlvbiB2aWV3X3N1Y2Nlc3MoXG4gIHByb3BzOiBSRVBMSW5wdXRQcm9wcyxcbiAgY29tbWFuZDogc3RyaW5nLFxuICBicmllZm1vZGU6IGJvb2xlYW4sXG4gIGRhdGE6IHN0cmluZ1tdW10gfCB1bmRlZmluZWRcbikge1xuICBpZiAoYnJpZWZtb2RlKSB7XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbLi4ucHJvcHMuaGlzdG9yeSwgPERhdGFUYWJsZSBkYXRhPXtkYXRhfT48L0RhdGFUYWJsZT5dKTtcbiAgfSBlbHNlIHtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJjb21tYW5kXCJ9PkNvbW1hbmQ6IHtjb21tYW5kfTwvZGl2PixcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtcInN1Y2Nlc3NcIn0+T3V0cHV0OjwvZGl2PixcbiAgICAgIDxEYXRhVGFibGUgZGF0YT17ZGF0YX0+PC9EYXRhVGFibGU+LFxuICAgIF0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVycm9yX21lc3NhZ2UoXG4gIHByb3BzOiBSRVBMSW5wdXRQcm9wcyxcbiAgYnJpZWZtb2RlOiBib29sZWFuLFxuICBjb21tYW5kOiBzdHJpbmdcbikge1xuICBpZiAoYnJpZWZtb2RlKSB7XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAuLi5wcm9wcy5oaXN0b3J5LFxuICAgICAgPGRpdiBjbGFzc05hbWU9e1wiZXJyb3JcIn0+aW52YWxpZCBjb21tYW5kIG9yIGFyZ3VtZW50czwvZGl2PixcbiAgICBdKTtcbiAgfSBlbHNlIHtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJjb21tYW5kXCJ9PkNvbW1hbmQ6IHtjb21tYW5kfTwvZGl2PixcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtcImVycm9yXCJ9Pk91dHB1dDogaW52YWxpZCBjb21tYW5kIG9yIGFyZ3VtZW50czwvZGl2PixcbiAgICBdKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzZWFyY2hfbm90X2xvYWRlZChcbiAgcHJvcHM6IFJFUExJbnB1dFByb3BzLFxuICBicmllZm1vZGU6IGJvb2xlYW4sXG4gIGNvbW1hbmQ6IHN0cmluZ1xuKSB7XG4gIGlmIChicmllZm1vZGUpIHtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5kYXRhIG5vdCBsb2FkZWQ8L2Rpdj4sXG4gICAgXSk7XG4gIH0gZWxzZSB7XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAuLi5wcm9wcy5oaXN0b3J5LFxuICAgICAgPGRpdiBjbGFzc05hbWU9e1wiY29tbWFuZFwifT5Db21tYW5kOiB7Y29tbWFuZH08L2Rpdj4sXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5PdXRwdXQ6IGRhdGEgbm90IGxvYWRlZDwvZGl2PixcbiAgICBdKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzZWFyY2hfbG9hZGVkKFxuICBwcm9wczogUkVQTElucHV0UHJvcHMsXG4gIGJyaWVmbW9kZTogYm9vbGVhbixcbiAgY29tbWFuZDogc3RyaW5nXG4pIHtcbiAgdmFyIHNlYXJjaFN0cmluZyA9IGNvbW1hbmQuc3Vic3RyaW5nKHNlYXJjaExlbmd0aCwgY29tbWFuZC5sZW5ndGgpO1xuICB2YXIgdmFsaWRBcmd1bWVudHMgPSBjb21tYW5kXG4gICAgLnN1YnN0cmluZyhzZWFyY2hMZW5ndGgsIGNvbW1hbmQubGVuZ3RoKVxuICAgIC5pbmNsdWRlcyhcIiBcIik7XG4gIHZhciBzZWFyY2hWYWxpZCA9IHF1ZXJ5VG9TZWFyY2hlZENTVk1hcC5oYXMoc2VhcmNoU3RyaW5nKTtcblxuICBpZiAodmFsaWRBcmd1bWVudHMpIHtcbiAgICBpZiAoc2VhcmNoVmFsaWQpIHtcbiAgICAgIGlmIChicmllZm1vZGUpIHtcbiAgICAgICAgdmFyIGRhdGEgPSBxdWVyeVRvU2VhcmNoZWRDU1ZNYXAuZ2V0KHNlYXJjaFN0cmluZyk7XG4gICAgICAgIHByb3BzLnNldEhpc3RvcnkoW1xuICAgICAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICAgICAgPERhdGFUYWJsZSBkYXRhPXtkYXRhfT48L0RhdGFUYWJsZT4sXG4gICAgICAgIF0pO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWJyaWVmbW9kZSkge1xuICAgICAgICB2YXIgZGF0YSA9IHF1ZXJ5VG9TZWFyY2hlZENTVk1hcC5nZXQoc2VhcmNoU3RyaW5nKTtcbiAgICAgICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAgICAgLi4ucHJvcHMuaGlzdG9yeSxcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17XCJjb21tYW5kXCJ9PkNvbW1hbmQ6IHtjb21tYW5kfTwvZGl2PixcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17XCJzdWNjZXNzXCJ9Pk91dHB1dDo8L2Rpdj4sXG4gICAgICAgICAgPERhdGFUYWJsZSBkYXRhPXtkYXRhfT48L0RhdGFUYWJsZT4sXG4gICAgICAgIF0pO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICghc2VhcmNoVmFsaWQpIHtcbiAgICAgIGlmIChicmllZm1vZGUpIHtcbiAgICAgICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAgICAgLi4ucHJvcHMuaGlzdG9yeSxcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5xdWVyeSBub3QgZm91bmQgaW4gZ2l2ZW4gY29sdW1uPC9kaXY+LFxuICAgICAgICBdKTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFicmllZm1vZGUpIHtcbiAgICAgICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAgICAgLi4ucHJvcHMuaGlzdG9yeSxcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17XCJjb21tYW5kXCJ9PkNvbW1hbmQ6IHtjb21tYW5kfTwvZGl2PixcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5cbiAgICAgICAgICAgIE91dHB1dDogcXVlcnkgbm90IGZvdW5kIGluIGdpdmVuIGNvbHVtblxuICAgICAgICAgIDwvZGl2PixcbiAgICAgICAgXSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaWYgKCF2YWxpZEFyZ3VtZW50cykge1xuICAgIGlmIChicmllZm1vZGUpIHtcbiAgICAgIHByb3BzLnNldEhpc3RvcnkoW1xuICAgICAgICAuLi5wcm9wcy5oaXN0b3J5LFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5pbnZhbGlkIG51bWJlciBvZiBhcmd1bWVudHM8L2Rpdj4sXG4gICAgICBdKTtcbiAgICB9XG5cbiAgICBpZiAoIWJyaWVmbW9kZSkge1xuICAgICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtcImNvbW1hbmRcIn0+Q29tbWFuZDoge2NvbW1hbmR9PC9kaXY+LFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5PdXRwdXQ6IGludmFsaWQgbnVtYmVyIG9mIGFyZ3VtZW50czwvZGl2PixcbiAgICAgIF0pO1xuICAgIH1cbiAgfVxufVxuIl0sImZpbGUiOiIvVXNlcnMvYWxleGFuZGVyemhvdS9EZXNrdG9wL2NzMzIvbW9jay1hemhvdTc2LW1kaW5nMTYvc3JjL2NvbXBvbmVudHMvUkVQTElucHV0LnRzeCJ9