import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MiscComponents/ControlledInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0a4e3deb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/MiscComponents/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function ControlledInput({
  value,
  setValue,
  ariaLabel
}) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "repl-command-box", value, placeholder: "start typing command...", onChange: (ev) => setValue(ev.target.value), "aria-label": ariaLabel }, void 0, false, {
    fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/MiscComponents/ControlledInput.tsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/MiscComponents/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJNO0FBakJOLE9BQU87QUFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZXJCLGdCQUFTQSxnQkFBZ0I7QUFBQSxFQUFDQztBQUFBQSxFQUFPQztBQUFBQSxFQUFVQztBQUErQixHQUFHO0FBQ2xGLFNBQ0UsdUJBQUMsV0FBTSxNQUFLLFFBQU8sV0FBVSxvQkFDdkIsT0FDQSxhQUFZLDJCQUNaLFVBQVdDLFFBQU9GLFNBQVNFLEdBQUdDLE9BQU9KLEtBQUssR0FDMUMsY0FBWUUsYUFKbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRUo7QUFBQ0csS0FUZU47QUFBZSxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ29udHJvbGxlZElucHV0IiwidmFsdWUiLCJzZXRWYWx1ZSIsImFyaWFMYWJlbCIsImV2IiwidGFyZ2V0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb250cm9sbGVkSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi4vLi4vc3R5bGVzL21haW4uY3NzJztcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiB9IGZyb20gJ3JlYWN0JztcblxuLy8gUmVtZW1iZXIgdGhhdCBwYXJhbWV0ZXIgbmFtZXMgZG9uJ3QgbmVjZXNzYXJpbHkgbmVlZCB0byBvdmVybGFwO1xuLy8gSSBjb3VsZCB1c2UgZGlmZmVyZW50IHZhcmlhYmxlIG5hbWVzIGluIHRoZSBhY3R1YWwgZnVuY3Rpb24uXG5pbnRlcmZhY2UgQ29udHJvbGxlZElucHV0UHJvcHMge1xuICAgIHZhbHVlOiBzdHJpbmcsIFxuICAgIC8vIFRoaXMgdHlwZSBjb21lcyBmcm9tIFJlYWN0K1R5cGVTY3JpcHQuIFZTQ29kZSBjYW4gc3VnZ2VzdCB0aGVzZS5cbiAgICAvLyAgIENvbmNyZXRlbHksIHRoaXMgbWVhbnMgXCJhIGZ1bmN0aW9uIHRoYXQgc2V0cyBhIHN0YXRlIGNvbnRhaW5pbmcgYSBzdHJpbmdcIlxuICAgIHNldFZhbHVlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PixcbiAgICBhcmlhTGFiZWw6IHN0cmluZyBcbiAgfVxuICBcbiAgLy8gSW5wdXQgYm94ZXMgY29udGFpbiBzdGF0ZS4gV2Ugd2FudCB0byBtYWtlIHN1cmUgUmVhY3QgaXMgbWFuYWdpbmcgdGhhdCBzdGF0ZSxcbiAgLy8gICBzbyB3ZSBoYXZlIGEgc3BlY2lhbCBjb21wb25lbnQgdGhhdCB3cmFwcyB0aGUgaW5wdXQgYm94LlxuICBleHBvcnQgZnVuY3Rpb24gQ29udHJvbGxlZElucHV0KHt2YWx1ZSwgc2V0VmFsdWUsIGFyaWFMYWJlbH06IENvbnRyb2xsZWRJbnB1dFByb3BzKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzTmFtZT1cInJlcGwtY29tbWFuZC1ib3hcIlxuICAgICAgICAgICAgdmFsdWU9e3ZhbHVlfSBcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwic3RhcnQgdHlwaW5nIGNvbW1hbmQuLi5cIlxuICAgICAgICAgICAgb25DaGFuZ2U9eyhldikgPT4gc2V0VmFsdWUoZXYudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2FyaWFMYWJlbH0+XG4gICAgICA8L2lucHV0PlxuICAgICk7XG4gIH0iXSwiZmlsZSI6Ii9Vc2Vycy9hbGV4YW5kZXJ6aG91L0Rlc2t0b3AvY3MzMi9tb2NrLWF6aG91NzYtbWRpbmcxNi9zcmMvY29tcG9uZW50cy9NaXNjQ29tcG9uZW50cy9Db250cm9sbGVkSW5wdXQudHN4In0=