import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=78303414"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css?t=1697152226274";
export function REPLHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "container", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "command-box", children: [
      "VALID COMMANDS:",
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx",
        lineNumber: 22,
        columnNumber: 9
      }, this),
      'load_file "filepath"',
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx",
        lineNumber: 24,
        columnNumber: 9
      }, this),
      "view",
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx",
        lineNumber: 26,
        columnNumber: 9
      }, this),
      'search "identifier" "tosearch"',
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx",
        lineNumber: 28,
        columnNumber: 9
      }, this),
      "mode",
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx",
        lineNumber: 30,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "repl-history", "data-testid": "repl-history", children: props.history.map((value) => /* @__PURE__ */ jsxDEV("div", { children: value }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx",
      lineNumber: 35,
      columnNumber: 37
    }, this)) }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JRO0FBdEJSLDJCQUFzQjtBQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDL0IsT0FBTztBQWVBLGdCQUFTQSxZQUFZQyxPQUF5QjtBQUNuRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGVBQWE7QUFBQTtBQUFBLE1BRTFCLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFJO0FBQUEsTUFBSTtBQUFBLE1BRVIsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUk7QUFBQSxNQUFJO0FBQUEsTUFFUix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBSTtBQUFBLE1BQUk7QUFBQSxNQUVSLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFJO0FBQUEsTUFBSTtBQUFBLE1BRVIsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUk7QUFBQSxTQVZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGdCQUFlLGVBQVksZ0JBQ3ZDQSxnQkFBTUMsUUFBUUMsSUFBS0MsV0FDbEIsdUJBQUMsU0FBS0EsbUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZLENBQ2IsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBO0FBRUo7QUFBQ0MsS0F6QmVMO0FBQVcsSUFBQUs7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJFUExIaXN0b3J5IiwicHJvcHMiLCJoaXN0b3J5IiwibWFwIiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExIaXN0b3J5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjbGVhciB9IGZyb20gXCJjb25zb2xlXCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcblxuLyoqXG4gKiBSRVBMSGlzdG9yeVByb3BzXG4gKiBAZmllbGQgaGlzdG9yeTogYXJyYXkgb2YgSlNYIGVsZW1lbnRzIHJlcHJlc2VudGluZyBjb21tYW5kIGhpc3RvcnkgXG4gKi9cbmludGVyZmFjZSBSRVBMSGlzdG9yeVByb3BzIHtcbiAgaGlzdG9yeTogSlNYLkVsZW1lbnRbXTtcbn1cblxuLyoqXG4gKiBSRVBMSGlzdG9yeVxuICogQHBhcmFtIHByb3BzIGNvbnRhaW5zIGNvbW1hbmQgaGlzdG9yeVxuICogQHJldHVybnMgZWFjaCBKU1ggZWxlbWVudCBpbiBoaXN0b3J5IGFycmF5IFxuICovXG5leHBvcnQgZnVuY3Rpb24gUkVQTEhpc3RvcnkocHJvcHM6IFJFUExIaXN0b3J5UHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgey8qKiBMRUZUIE9GIFJFUEwgSElTVE9SWSBVSTogTElTVCBPRiBWQUxJRCBDT01NQU5EUyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29tbWFuZC1ib3hcIj5cbiAgICAgICAgVkFMSUQgQ09NTUFORFM6XG4gICAgICAgIDxocj48L2hyPlxuICAgICAgICBsb2FkX2ZpbGUgXCJmaWxlcGF0aFwiXG4gICAgICAgIDxocj48L2hyPlxuICAgICAgICB2aWV3XG4gICAgICAgIDxocj48L2hyPlxuICAgICAgICBzZWFyY2ggXCJpZGVudGlmaWVyXCIgXCJ0b3NlYXJjaFwiXG4gICAgICAgIDxocj48L2hyPlxuICAgICAgICBtb2RlXG4gICAgICAgIDxocj48L2hyPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiogUklHSFQgT0YgUkVQTCBISVNUT1JZIFVJOiBDT01NQU5EIEhJU1RPUlkgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaGlzdG9yeVwiIGRhdGEtdGVzdGlkPVwicmVwbC1oaXN0b3J5XCI+XG4gICAgICAgIHtwcm9wcy5oaXN0b3J5Lm1hcCgodmFsdWUpID0+IChcbiAgICAgICAgICA8ZGl2Pnt2YWx1ZX08L2Rpdj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL21pY2hlbGxlZGluZy9EZXNrdG9wL0NTMzJBc3NpZ25tZW50cy9tb2NrLWF6aG91NzYtbWRpbmcxNi9zcmMvY29tcG9uZW50cy9SRVBMSGlzdG9yeS50c3gifQ==