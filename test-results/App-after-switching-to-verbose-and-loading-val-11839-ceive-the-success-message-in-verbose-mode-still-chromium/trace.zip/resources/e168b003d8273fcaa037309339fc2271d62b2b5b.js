import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MiscComponents/ControlledInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=78303414"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/MiscComponents/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css?t=1697152226274";
export function ControlledInput({
  value,
  setValue,
  ariaLabel
}) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "repl-command-box", value, placeholder: "start typing command...", onChange: (ev) => setValue(ev.target.value), "aria-label": ariaLabel }, void 0, false, {
    fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/MiscComponents/ControlledInput.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/MiscComponents/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU07QUFmTixPQUFPO0FBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWFyQixnQkFBU0EsZ0JBQWdCO0FBQUEsRUFBQ0M7QUFBQUEsRUFBT0M7QUFBQUEsRUFBVUM7QUFBK0IsR0FBRztBQUNsRixTQUNFLHVCQUFDLFdBQU0sTUFBSyxRQUFPLFdBQVUsb0JBQ3ZCLE9BQ0EsYUFBWSwyQkFDWixVQUFXQyxRQUFPRixTQUFTRSxHQUFHQyxPQUFPSixLQUFLLEdBQzFDLGNBQVlFLGFBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQTtBQUVKO0FBQUNHLEtBVGVOO0FBQWUsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkNvbnRyb2xsZWRJbnB1dCIsInZhbHVlIiwic2V0VmFsdWUiLCJhcmlhTGFiZWwiLCJldiIsInRhcmdldCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udHJvbGxlZElucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4uLy4uL3N0eWxlcy9tYWluLmNzcyc7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24gfSBmcm9tICdyZWFjdCc7XG5cbi8qKlxuICogQ29udHJvbGxlZElucHV0UHJvcHMgaW50ZXJmYWNlXG4gKi9cbmludGVyZmFjZSBDb250cm9sbGVkSW5wdXRQcm9wcyB7XG4gICAgdmFsdWU6IHN0cmluZywgXG4gICAgc2V0VmFsdWU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+LFxuICAgIGFyaWFMYWJlbDogc3RyaW5nIFxuICB9XG4gIFxuXG4gIGV4cG9ydCBmdW5jdGlvbiBDb250cm9sbGVkSW5wdXQoe3ZhbHVlLCBzZXRWYWx1ZSwgYXJpYUxhYmVsfTogQ29udHJvbGxlZElucHV0UHJvcHMpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3NOYW1lPVwicmVwbC1jb21tYW5kLWJveFwiXG4gICAgICAgICAgICB2YWx1ZT17dmFsdWV9IFxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJzdGFydCB0eXBpbmcgY29tbWFuZC4uLlwiXG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2KSA9PiBzZXRWYWx1ZShldi50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD17YXJpYUxhYmVsfT5cbiAgICAgIDwvaW5wdXQ+XG4gICAgKTtcbiAgfSJdLCJmaWxlIjoiL1VzZXJzL21pY2hlbGxlZGluZy9EZXNrdG9wL0NTMzJBc3NpZ25tZW50cy9tb2NrLWF6aG91NzYtbWRpbmcxNi9zcmMvY29tcG9uZW50cy9NaXNjQ29tcG9uZW50cy9Db250cm9sbGVkSW5wdXQudHN4In0=