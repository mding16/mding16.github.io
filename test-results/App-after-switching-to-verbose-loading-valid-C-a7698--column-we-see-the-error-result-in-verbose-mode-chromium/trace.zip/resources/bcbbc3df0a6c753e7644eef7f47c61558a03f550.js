import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/StatusComponents/ModeStatus.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=78303414"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/ModeStatus.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function ModeStatus(props) {
  if (props.mode) {
    return /* @__PURE__ */ jsxDEV("div", { className: "briefmode", children: [
      "BRIEF MODE",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/ModeStatus.tsx",
        lineNumber: 7,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "smalltext", children: "(type 'mode' to change to verbose)" }, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/ModeStatus.tsx",
        lineNumber: 8,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/ModeStatus.tsx",
      lineNumber: 6,
      columnNumber: 12
    }, this);
  } else {
    return /* @__PURE__ */ jsxDEV("div", { className: "verbosemode", children: [
      "VERBOSE MODE",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/ModeStatus.tsx",
        lineNumber: 12,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "smalltext", children: "(type 'mode' to change to brief)" }, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/ModeStatus.tsx",
        lineNumber: 13,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/ModeStatus.tsx",
      lineNumber: 11,
      columnNumber: 12
    }, this);
  }
}
_c = ModeStatus;
var _c;
$RefreshReg$(_c, "ModeStatus");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/ModeStatus.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1E7QUFQUiwyQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSW5CLGdCQUFTQSxXQUFZQyxPQUF3QjtBQUNoRCxNQUFJQSxNQUFNQyxNQUFLO0FBQ1gsV0FBTyx1QkFBQyxTQUFJLFdBQVUsYUFBWTtBQUFBO0FBQUEsTUFDbEMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUk7QUFBQSxNQUNKLHVCQUFDLFNBQUksV0FBWSxhQUFZLGtEQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStEO0FBQUEsU0FGeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdQO0FBQUEsRUFDSixPQUNJO0FBQ0EsV0FBTyx1QkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBO0FBQUEsTUFDcEMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUk7QUFBQSxNQUNKLHVCQUFDLFNBQUksV0FBWSxhQUFZLGdEQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsU0FGdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUU0RDtBQUFBLEVBQ3ZFO0FBQ0o7QUFBQ0MsS0FaZUg7QUFBVSxJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTW9kZVN0YXR1cyIsInByb3BzIiwibW9kZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTW9kZVN0YXR1cy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW50ZXJmYWNlIE1vZGVTdGF0dXNQcm9wcyB7XG4gICAgbW9kZTogYm9vbGVhbjtcbiAgfVxuXG5leHBvcnQgZnVuY3Rpb24gTW9kZVN0YXR1cyAocHJvcHM6IE1vZGVTdGF0dXNQcm9wcykge1xuICAgIGlmIChwcm9wcy5tb2RlKXtcbiAgICAgICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiYnJpZWZtb2RlXCI+QlJJRUYgTU9ERSBcbiAgICAgICAgPGJyPjwvYnI+IFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZSA9IFwic21hbGx0ZXh0XCI+KHR5cGUgJ21vZGUnIHRvIGNoYW5nZSB0byB2ZXJib3NlKTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgZWxzZXtcbiAgICAgICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidmVyYm9zZW1vZGVcIj5WRVJCT1NFIE1PREUgXG4gICAgICAgIDxicj48L2JyPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZSA9IFwic21hbGx0ZXh0XCI+KHR5cGUgJ21vZGUnIHRvIGNoYW5nZSB0byBicmllZik8L2Rpdj48L2Rpdj5cbiAgICB9XG59Il0sImZpbGUiOiIvVXNlcnMvbWljaGVsbGVkaW5nL0Rlc2t0b3AvQ1MzMkFzc2lnbm1lbnRzL21vY2stYXpob3U3Ni1tZGluZzE2L3NyYy9jb21wb25lbnRzL1N0YXR1c0NvbXBvbmVudHMvTW9kZVN0YXR1cy50c3gifQ==