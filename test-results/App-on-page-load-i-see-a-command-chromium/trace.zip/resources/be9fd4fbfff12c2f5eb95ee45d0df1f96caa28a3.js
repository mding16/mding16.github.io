import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/StatusComponents/LoadStatus.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f2782790"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/LoadStatus.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function LoadStatus(props) {
  if (props.loadStatus === 0) {
    return /* @__PURE__ */ jsxDEV("div", { className: "notloaded", children: [
      "DATA NOT LOADED",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/LoadStatus.tsx",
        lineNumber: 9,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "smalltext", children: "(type 'load_file filePath' to load data)" }, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/LoadStatus.tsx",
        lineNumber: 10,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/LoadStatus.tsx",
      lineNumber: 7,
      columnNumber: 12
    }, this);
  } else {
    return /* @__PURE__ */ jsxDEV("div", { className: "loaded", children: [
      "DATA LOADED:",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/LoadStatus.tsx",
        lineNumber: 17,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "smalltext", children: props.csvFile }, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/LoadStatus.tsx",
        lineNumber: 18,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/LoadStatus.tsx",
      lineNumber: 15,
      columnNumber: 12
    }, this);
  }
}
_c = LoadStatus;
var _c;
$RefreshReg$(_c, "LoadStatus");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/StatusComponents/LoadStatus.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1k7QUFUWiwyQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBS25CLGdCQUFTQSxXQUFZQyxPQUF3QjtBQUNoRCxNQUFJQSxNQUFNQyxlQUFlLEdBQUU7QUFDdkIsV0FBTyx1QkFBQyxTQUFJLFdBQVUsYUFBVztBQUFBO0FBQUEsTUFFN0IsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUk7QUFBQSxNQUNKLHVCQUFDLFNBQUksV0FBVSxhQUFXLHdEQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNSDtBQUFBLEVBQ1IsT0FDSTtBQUNBLFdBQU8sdUJBQUMsU0FBSSxXQUFVLFVBQVE7QUFBQTtBQUFBLE1BRTFCLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFJO0FBQUEsTUFDSix1QkFBQyxTQUFJLFdBQVUsYUFBYUQsZ0JBQU1FLFdBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEM7QUFBQSxTQUh2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUg7QUFBQSxFQUNSO0FBQ0o7QUFBQ0MsS0FqQmVKO0FBQVUsSUFBQUk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkxvYWRTdGF0dXMiLCJwcm9wcyIsImxvYWRTdGF0dXMiLCJjc3ZGaWxlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJMb2FkU3RhdHVzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbnRlcmZhY2UgTG9hZFN0YXR1c1Byb3BzIHtcbiAgICBsb2FkU3RhdHVzOiBOdW1iZXI7XG4gICAgY3N2RmlsZTogU3RyaW5nXG4gIH1cblxuZXhwb3J0IGZ1bmN0aW9uIExvYWRTdGF0dXMgKHByb3BzOiBMb2FkU3RhdHVzUHJvcHMpIHtcbiAgICBpZiAocHJvcHMubG9hZFN0YXR1cyA9PT0gMCl7XG4gICAgICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cIm5vdGxvYWRlZFwiPlxuICAgICAgICAgICAgREFUQSBOT1QgTE9BREVEXG4gICAgICAgICAgICA8YnI+PC9icj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic21hbGx0ZXh0XCI+XG4gICAgICAgICAgICAgICAgKHR5cGUgJ2xvYWRfZmlsZSBmaWxlUGF0aCcgdG8gbG9hZCBkYXRhKVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICB9XG4gICAgZWxzZXtcbiAgICAgICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwibG9hZGVkXCI+XG4gICAgICAgICAgICBEQVRBIExPQURFRDogXG4gICAgICAgICAgICA8YnI+PC9icj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic21hbGx0ZXh0XCI+e3Byb3BzLmNzdkZpbGV9PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICB9XG59Il0sImZpbGUiOiIvVXNlcnMvbWljaGVsbGVkaW5nL0Rlc2t0b3AvQ1MzMkFzc2lnbm1lbnRzL21vY2stYXpob3U3Ni1tZGluZzE2L3NyYy9jb21wb25lbnRzL1N0YXR1c0NvbXBvbmVudHMvTG9hZFN0YXR1cy50c3gifQ==