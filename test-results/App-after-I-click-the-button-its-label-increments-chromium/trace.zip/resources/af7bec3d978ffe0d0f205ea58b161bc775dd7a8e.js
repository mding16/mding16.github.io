import {
  require_react
} from "/node_modules/.vite/deps/chunk-FW626NKP.js?v=f2782790";
import "/node_modules/.vite/deps/chunk-CQXHTUV2.js?v=f2782790";
export default require_react();
//# sourceMappingURL=react.js.map
