import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f2782790"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import { ModeStatus } from "/src/components/StatusComponents/ModeStatus.tsx";
import { LoadStatus } from "/src/components/StatusComponents/LoadStatus.tsx";
import { DataTable } from "/src/components/MiscComponents/DataTable.tsx";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=f2782790"; const useState = __vite__cjsImport7_react["useState"];
import { ControlledInput } from "/src/components/MiscComponents/ControlledInput.tsx?t=1697063652195";
import { filepathToParsedCSVMap, queryToSearchedCSVMap } from "/src/components/Mock/mockedJson.ts";
const searchLength = 7;
const loadLength = 10;
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [dataLoaded, setDataLoaded] = useState(0);
  const [data, setData] = useState();
  const [csvFilePath, setFilePath] = useState("");
  const [briefmode, setMode] = useState(true);
  function handleSubmit(commandString2) {
    {
    }
    if (commandString2 === "mode") {
      setMode(!briefmode);
      {
      }
    } else if (commandString2.length >= loadLength && commandString2.substring(0, loadLength) === "load_file ") {
      var filePath = commandString2.substring(loadLength, commandString2.length);
      if (filepathToParsedCSVMap.has(filePath)) {
        setData(filepathToParsedCSVMap.get(filePath));
        setDataLoaded(1);
        setFilePath(filePath);
        load_csv_success(props, briefmode, commandString2);
      } else {
        load_csv_fail(props, briefmode, commandString2);
      }
      {
      }
    } else if (commandString2 === "view" && dataLoaded === 0) {
      view_fail(props, briefmode, commandString2);
    } else if (commandString2 === "view" && dataLoaded === 1) {
      view_success(props, commandString2, briefmode, data);
      {
      }
    } else if (commandString2.length >= searchLength && commandString2.substring(0, searchLength) === "search " && dataLoaded === 0) {
      search_not_loaded(props, briefmode, commandString2);
    } else if (commandString2.length >= searchLength && commandString2.substring(0, searchLength) === "search " && dataLoaded === 1) {
      search_loaded(props, briefmode, commandString2);
    } else {
      error_message(props, briefmode, commandString2);
    }
    {
    }
    setCount(count + 1);
    setCommandString("");
  }
  {
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "container", children: [
      /* @__PURE__ */ jsxDEV(ModeStatus, { mode: briefmode }, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 62,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(LoadStatus, { loadStatus: dataLoaded, csvFile: csvFilePath }, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 63,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 60,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container1", children: /* @__PURE__ */ jsxDEV("div", { className: "history", children: "COMMANDS" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 66,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 65,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container2", children: [
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 71,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 72,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: /* @__PURE__ */ jsxDEV("div", { className: "buttontext", children: [
        "Submitted ",
        count,
        " time(s)"
      ] }, void 0, true, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 76,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 75,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 70,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
    lineNumber: 59,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "qqh86pXp8iNB55NFdhkPaaPiG/g=");
_c = REPLInput;
function load_csv_success(props, briefmode, command) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "success", children: "Successfully loaded CSV" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 85,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 87,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "success", children: "Output: successfully loaded csv" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 87,
      columnNumber: 94
    }, this)]);
  }
}
function load_csv_fail(props, briefmode, command) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "failed to load csv" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 92,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 94,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Output: failed to load csv" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 94,
      columnNumber: 94
    }, this)]);
  }
}
function view_fail(props, briefmode, command) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "data not loaded" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 99,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 101,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Output: data not loaded" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 101,
      columnNumber: 94
    }, this)]);
  }
}
function view_success(props, command, briefmode, data) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV(DataTable, { data }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 106,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 108,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV(DataTable, { data }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 108,
      columnNumber: 92
    }, this)]);
  }
}
function error_message(props, briefmode, command) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Invalid command or arguments" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 113,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 115,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Output: Invalid command or arguments" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 115,
      columnNumber: 94
    }, this)]);
  }
}
function search_not_loaded(props, briefmode, command) {
  if (briefmode) {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { children: "data not loaded" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 120,
      columnNumber: 41
    }, this)]);
  } else {
    props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
      "Command: ",
      command
    ] }, void 0, true, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 122,
      columnNumber: 41
    }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Output: data not loaded" }, void 0, false, {
      fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
      lineNumber: 122,
      columnNumber: 94
    }, this)]);
  }
}
function search_loaded(props, briefmode, command) {
  var searchString = command.substring(searchLength, command.length);
  var validArguments = command.substring(searchLength, command.length).includes(" ");
  var searchValid = queryToSearchedCSVMap.has(searchString);
  if (validArguments) {
    if (searchValid) {
      if (briefmode) {
        var data = queryToSearchedCSVMap.get(searchString);
        props.setHistory([...props.history, /* @__PURE__ */ jsxDEV(DataTable, { data }, void 0, false, {
          fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 133,
          columnNumber: 45
        }, this)]);
      }
      if (!briefmode) {
        var data = queryToSearchedCSVMap.get(searchString);
        props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
          "Command: ",
          command
        ] }, void 0, true, {
          fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 137,
          columnNumber: 45
        }, this), /* @__PURE__ */ jsxDEV("div", { className: "success", children: "Output:" }, void 0, false, {
          fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 137,
          columnNumber: 96
        }, this), /* @__PURE__ */ jsxDEV(DataTable, { data }, void 0, false, {
          fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 137,
          columnNumber: 136
        }, this)]);
      }
    }
    if (!searchValid) {
      if (briefmode) {
        props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Invalid search" }, void 0, false, {
          fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 142,
          columnNumber: 45
        }, this)]);
      }
      if (!briefmode) {
        props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
          "Command: ",
          command
        ] }, void 0, true, {
          fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 145,
          columnNumber: 45
        }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Invalid search" }, void 0, false, {
          fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
          lineNumber: 145,
          columnNumber: 96
        }, this)]);
      }
    }
  }
  if (!validArguments) {
    if (briefmode) {
      props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Invalid number of arguments" }, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 151,
        columnNumber: 43
      }, this)]);
    }
    if (!briefmode) {
      props.setHistory([...props.history, /* @__PURE__ */ jsxDEV("div", { className: "command", children: [
        "Command: ",
        command
      ] }, void 0, true, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 154,
        columnNumber: 43
      }, this), /* @__PURE__ */ jsxDEV("div", { className: "error", children: "Invalid number of arguments" }, void 0, false, {
        fileName: "/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx",
        lineNumber: 154,
        columnNumber: 94
      }, this)]);
    }
  }
}
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/michelleding/Desktop/CS32Assignments/mock-azhou76-mding16/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUZROzs7Ozs7Ozs7Ozs7Ozs7OztBQWpGUixPQUFPO0FBQ1AsU0FBU0Esa0JBQWtCO0FBQzNCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBbUNDLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msd0JBQXdCQyw2QkFBNkI7QUFVOUQsTUFBTUMsZUFBZTtBQUNyQixNQUFNQyxhQUFhO0FBRVosZ0JBQVNDLFVBQVVDLE9BQXVCO0FBQUFDLEtBQUE7QUFDL0MsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSVYsU0FBaUIsRUFBRTtBQUM3RCxRQUFNLENBQUNXLE9BQU9DLFFBQVEsSUFBSVosU0FBaUIsQ0FBQztBQUM1QyxRQUFNLENBQUNhLFlBQVlDLGFBQWEsSUFBSWQsU0FBaUIsQ0FBQztBQUN0RCxRQUFNLENBQUNlLE1BQU1DLE9BQU8sSUFBSWhCLFNBQWlDO0FBQ3pELFFBQUssQ0FBQ2lCLGFBQWFDLFdBQVcsSUFBSWxCLFNBQWlCLEVBQUU7QUFDckQsUUFBTSxDQUFDbUIsV0FBV0MsT0FBTyxJQUFJcEIsU0FBa0IsSUFBSTtBQUVuRCxXQUFTcUIsYUFBYVosZ0JBQXVCO0FBQzNDO0FBQUEsSUFBQztBQUNELFFBQUlBLG1CQUFrQixRQUFRO0FBQzVCVyxjQUFRLENBQUNELFNBQVM7QUFFakI7QUFBQSxNQUFDO0FBQUEsSUFDSixXQUNFVixlQUFjYSxVQUFVakIsY0FDeEJJLGVBQWNjLFVBQVUsR0FBR2xCLFVBQVUsTUFBTSxjQUMzQztBQUVBLFVBQUltQixXQUFXZixlQUFjYyxVQUMzQmxCLFlBQVlJLGVBQWNhLE1BQU07QUFDbEMsVUFBSXBCLHVCQUF1QnVCLElBQUlELFFBQVEsR0FBRztBQUN4Q1IsZ0JBQVFkLHVCQUF1QndCLElBQUlGLFFBQVEsQ0FBQztBQUM1Q1Ysc0JBQWMsQ0FBQztBQUNmSSxvQkFBWU0sUUFBUTtBQUNwQkcseUJBQWlCcEIsT0FBT1ksV0FBV1YsY0FBYTtBQUFBLE1BRWxELE9BQU87QUFBQ21CLHNCQUFjckIsT0FBT1ksV0FBV1YsY0FBYTtBQUFBLE1BQUM7QUFFdEQ7QUFBQSxNQUFDO0FBQUEsSUFDSCxXQUFXQSxtQkFBa0IsVUFBVUksZUFBZSxHQUFHO0FBQ3ZEZ0IsZ0JBQVV0QixPQUFPWSxXQUFXVixjQUFhO0FBQUEsSUFDM0MsV0FBV0EsbUJBQWtCLFVBQVVJLGVBQWUsR0FBRztBQUN2RGlCLG1CQUFhdkIsT0FBT0UsZ0JBQWVVLFdBQVdKLElBQUk7QUFFbEQ7QUFBQSxNQUFDO0FBQUEsSUFDSCxXQUNFTixlQUFjYSxVQUFVbEIsZ0JBQ3hCSyxlQUFjYyxVQUFVLEdBQUduQixZQUFZLE1BQU0sYUFDN0NTLGVBQWUsR0FDZjtBQUFDa0Isd0JBQWtCeEIsT0FBT1ksV0FBV1YsY0FBYTtBQUFBLElBQUUsV0FHcERBLGVBQWNhLFVBQVVsQixnQkFDeEJLLGVBQWNjLFVBQVUsR0FBR25CLFlBQVksTUFBTSxhQUM3Q1MsZUFBZSxHQUNmO0FBQ0FtQixvQkFBY3pCLE9BQU9ZLFdBQVdWLGNBQWE7QUFBQSxJQUMvQyxPQUFPO0FBQ0x3QixvQkFBYzFCLE9BQU9ZLFdBQVdWLGNBQWE7QUFBQSxJQUMvQztBQUVBO0FBQUEsSUFBQztBQUNERyxhQUFTRCxRQUFRLENBQUM7QUFDbEJELHFCQUFpQixFQUFFO0FBQUEsRUFDckI7QUFFQTtBQUFBLEVBQUM7QUFDRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGFBRWI7QUFBQSw2QkFBQyxjQUFXLE1BQU1TLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxNQUM3Qix1QkFBQyxjQUFXLFlBQVlOLFlBQVksU0FBU0ksZUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRDtBQUFBLFNBSDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFZLGNBQ2YsaUNBQUMsU0FBSSxXQUFZLFdBQVUsd0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUMsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLG1CQUNDLE9BQU9SLGVBQ1AsVUFBVUMsa0JBQ1YsV0FBVyxtQkFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRzZCO0FBQUEsTUFFN0IsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUk7QUFBQSxNQUdKLHVCQUFDLFlBQU8sU0FBUyxNQUFNVyxhQUFhWixhQUFhLEdBQy9DLGlDQUFDLFNBQUksV0FBVSxjQUFhO0FBQUE7QUFBQSxRQUFXRTtBQUFBQSxRQUFNO0FBQUEsV0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRCxLQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLE9BdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkU7QUFFTjtBQUFDSCxHQXJGZUYsV0FBUztBQUFBNEIsS0FBVDVCO0FBdUZoQixTQUFTcUIsaUJBQWlCcEIsT0FBdUJZLFdBQW9CZ0IsU0FBZ0I7QUFDbkYsTUFBSWhCLFdBQVc7QUFDYlosVUFBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFXLFdBQVcsdUNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0QsQ0FBTSxDQUN6RDtBQUFBLEVBQ0gsT0FBTztBQUNMOUIsVUFBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFXLFdBQVc7QUFBQTtBQUFBLE1BQVVGO0FBQUFBLFNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkMsR0FDN0MsdUJBQUMsU0FBSSxXQUFXLFdBQVcsK0NBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEQsQ0FBTSxDQUNqRTtBQUFBLEVBQ0g7QUFDRjtBQUVBLFNBQVNQLGNBQWNyQixPQUF1QlksV0FBb0JnQixTQUFnQjtBQUNoRixNQUFJaEIsV0FBVztBQUNiWixVQUFNNkIsV0FBVyxDQUNmLEdBQUc3QixNQUFNOEIsU0FDWCx1QkFBQyxTQUFJLFdBQVcsU0FBUyxrQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQyxDQUFNLENBQUM7QUFBQSxFQUNwRCxPQUFPO0FBQ0w5QixVQUFNNkIsV0FBVyxDQUNmLEdBQUc3QixNQUFNOEIsU0FDVCx1QkFBQyxTQUFJLFdBQVcsV0FBVztBQUFBO0FBQUEsTUFBVUY7QUFBQUEsU0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QyxHQUM3Qyx1QkFBQyxTQUFJLFdBQVcsU0FBUywwQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRCxDQUFNLENBQzFEO0FBQUEsRUFDSDtBQUNGO0FBRUEsU0FBU04sVUFBVXRCLE9BQXVCWSxXQUFvQmdCLFNBQWdCO0FBQzVFLE1BQUloQixXQUFXO0FBQ2JaLFVBQU02QixXQUFXLENBQUMsR0FBRzdCLE1BQU04QixTQUFTLHVCQUFDLFNBQUksV0FBVyxTQUFTLCtCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdDLENBQU0sQ0FBQztBQUFBLEVBQ3JGLE9BQU87QUFDTDlCLFVBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLFNBQUksV0FBVyxXQUFXO0FBQUE7QUFBQSxNQUFVRjtBQUFBQSxTQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZDLEdBQzdDLHVCQUFDLFNBQUksV0FBVyxTQUFTLHVDQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdELENBQU0sQ0FDekQ7QUFBQSxFQUNEO0FBQ0Y7QUFFQSxTQUFTTCxhQUFhdkIsT0FBdUI0QixTQUFpQmhCLFdBQW9CSixNQUE2QjtBQUM3RyxNQUFJSSxXQUFXO0FBQ2JaLFVBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLGFBQVUsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVCLENBQVksQ0FDcEM7QUFBQSxFQUNILE9BQU87QUFDTDlCLFVBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLFNBQUksV0FBWSxXQUFVO0FBQUE7QUFBQSxNQUFVRjtBQUFBQSxTQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZDLEdBQzdDLHVCQUFDLGFBQVUsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVCLENBQVksQ0FDcEM7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxTQUFTRixjQUFjMUIsT0FBdUJZLFdBQW9CZ0IsU0FBZ0I7QUFDaEYsTUFBSWhCLFdBQVc7QUFDYlosVUFBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFXLFNBQVMsNENBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUQsQ0FBTSxDQUM1RDtBQUFBLEVBQ0gsT0FBTztBQUNMOUIsVUFBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFZLFdBQVc7QUFBQTtBQUFBLE1BQVVGO0FBQUFBLFNBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEMsR0FDOUMsdUJBQUMsU0FBSSxXQUFXLFNBQVMsb0RBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkQsQ0FBTSxDQUNwRTtBQUFBLEVBQ0g7QUFDRjtBQUVBLFNBQVNKLGtCQUFrQnhCLE9BQXVCWSxXQUFvQmdCLFNBQWdCO0FBQ3BGLE1BQUloQixXQUFXO0FBQ2JaLFVBQU02QixXQUFXLENBQUMsR0FBRzdCLE1BQU04QixTQUFTLHVCQUFDLFNBQUksK0JBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQixDQUFNLENBQUM7QUFBQSxFQUNqRSxPQUFPO0FBQ0w5QixVQUFNNkIsV0FBVyxDQUNmLEdBQUc3QixNQUFNOEIsU0FDVCx1QkFBQyxTQUFJLFdBQVcsV0FBVztBQUFBO0FBQUEsTUFBVUY7QUFBQUEsU0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QyxHQUM3Qyx1QkFBQyxTQUFJLFdBQVcsU0FBUyx1Q0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRCxDQUFNLENBQ3ZEO0FBQUEsRUFDSDtBQUNGO0FBRUEsU0FBU0gsY0FBY3pCLE9BQXVCWSxXQUFvQmdCLFNBQWdCO0FBQ2hGLE1BQUlHLGVBQWVILFFBQVFaLFVBQVVuQixjQUFjK0IsUUFBUWIsTUFBTTtBQUNqRSxNQUFJaUIsaUJBQWlCSixRQUFRWixVQUFVbkIsY0FBYytCLFFBQVFiLE1BQU0sRUFBRWtCLFNBQVMsR0FBRztBQUNqRixNQUFJQyxjQUFjdEMsc0JBQXNCc0IsSUFBSWEsWUFBWTtBQUV4RCxNQUFJQyxnQkFBZTtBQUVqQixRQUFJRSxhQUFZO0FBRWQsVUFBSXRCLFdBQVU7QUFDWixZQUFJSixPQUFPWixzQkFBc0J1QixJQUFJWSxZQUFZO0FBQ2pEL0IsY0FBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsYUFBVSxRQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUIsQ0FBWSxDQUNwQztBQUFBLE1BQ0g7QUFFQSxVQUFJLENBQUNsQixXQUFXO0FBQ2QsWUFBSUosT0FBT1osc0JBQXNCdUIsSUFBSVksWUFBWTtBQUNqRC9CLGNBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLFNBQUksV0FBWSxXQUFVO0FBQUE7QUFBQSxVQUFVRjtBQUFBQSxhQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDLEdBQzdDLHVCQUFDLFNBQUksV0FBWSxXQUFVLHVCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDLEdBQ2xDLHVCQUFDLGFBQVUsUUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCLENBQVksQ0FDcEM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUVBLFFBQUksQ0FBQ00sYUFBWTtBQUNmLFVBQUl0QixXQUFVO0FBQ1paLGNBQU02QixXQUFXLENBQ2YsR0FBRzdCLE1BQU04QixTQUNULHVCQUFDLFNBQUksV0FBWSxTQUFRLDhCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDLENBQU0sQ0FDOUM7QUFBQSxNQUNIO0FBRUEsVUFBSSxDQUFDbEIsV0FBVTtBQUNiWixjQUFNNkIsV0FBVyxDQUNmLEdBQUc3QixNQUFNOEIsU0FDVCx1QkFBQyxTQUFJLFdBQVksV0FBVTtBQUFBO0FBQUEsVUFBVUY7QUFBQUEsYUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QyxHQUM3Qyx1QkFBQyxTQUFJLFdBQVksU0FBUSw4QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QyxDQUFNLENBQzlDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsTUFBSSxDQUFDSSxnQkFBZTtBQUNsQixRQUFJcEIsV0FBVTtBQUNaWixZQUFNNkIsV0FBVyxDQUNmLEdBQUc3QixNQUFNOEIsU0FDVCx1QkFBQyxTQUFJLFdBQVksU0FBUSwyQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRCxDQUFNLENBQzNEO0FBQUEsSUFDSDtBQUVBLFFBQUksQ0FBQ2xCLFdBQVc7QUFDZFosWUFBTTZCLFdBQVcsQ0FDZixHQUFHN0IsTUFBTThCLFNBQ1QsdUJBQUMsU0FBSSxXQUFZLFdBQVU7QUFBQTtBQUFBLFFBQVVGO0FBQUFBLFdBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkMsR0FDN0MsdUJBQUMsU0FBSSxXQUFZLFNBQVEsMkNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0QsQ0FBTSxDQUMzRDtBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0Y7QUFBQyxJQUFBRDtBQUFBUSxhQUFBUixJQUFBIiwibmFtZXMiOlsiTW9kZVN0YXR1cyIsIkxvYWRTdGF0dXMiLCJEYXRhVGFibGUiLCJ1c2VTdGF0ZSIsIkNvbnRyb2xsZWRJbnB1dCIsImZpbGVwYXRoVG9QYXJzZWRDU1ZNYXAiLCJxdWVyeVRvU2VhcmNoZWRDU1ZNYXAiLCJzZWFyY2hMZW5ndGgiLCJsb2FkTGVuZ3RoIiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiY291bnQiLCJzZXRDb3VudCIsImRhdGFMb2FkZWQiLCJzZXREYXRhTG9hZGVkIiwiZGF0YSIsInNldERhdGEiLCJjc3ZGaWxlUGF0aCIsInNldEZpbGVQYXRoIiwiYnJpZWZtb2RlIiwic2V0TW9kZSIsImhhbmRsZVN1Ym1pdCIsImxlbmd0aCIsInN1YnN0cmluZyIsImZpbGVQYXRoIiwiaGFzIiwiZ2V0IiwibG9hZF9jc3Zfc3VjY2VzcyIsImxvYWRfY3N2X2ZhaWwiLCJ2aWV3X2ZhaWwiLCJ2aWV3X3N1Y2Nlc3MiLCJzZWFyY2hfbm90X2xvYWRlZCIsInNlYXJjaF9sb2FkZWQiLCJlcnJvcl9tZXNzYWdlIiwiX2MiLCJjb21tYW5kIiwic2V0SGlzdG9yeSIsImhpc3RvcnkiLCJzZWFyY2hTdHJpbmciLCJ2YWxpZEFyZ3VtZW50cyIsImluY2x1ZGVzIiwic2VhcmNoVmFsaWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgTW9kZVN0YXR1cyB9IGZyb20gXCIuL1N0YXR1c0NvbXBvbmVudHMvTW9kZVN0YXR1c1wiO1xuaW1wb3J0IHsgTG9hZFN0YXR1cyB9IGZyb20gXCIuL1N0YXR1c0NvbXBvbmVudHMvTG9hZFN0YXR1c1wiO1xuaW1wb3J0IHsgRGF0YVRhYmxlIH0gZnJvbSBcIi4vTWlzY0NvbXBvbmVudHMvRGF0YVRhYmxlXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9NaXNjQ29tcG9uZW50cy9Db250cm9sbGVkSW5wdXRcIjtcbmltcG9ydCB7IGZpbGVwYXRoVG9QYXJzZWRDU1ZNYXAsIHF1ZXJ5VG9TZWFyY2hlZENTVk1hcCB9IGZyb20gXCIuL01vY2svbW9ja2VkSnNvblwiO1xuaW1wb3J0IHsgdW5zdGFibGVfcmVuZGVyU3VidHJlZUludG9Db250YWluZXIgfSBmcm9tIFwicmVhY3QtZG9tXCI7XG5pbXBvcnQgeyBnZXRQYXJzZWRDb21tYW5kTGluZU9mQ29uZmlnRmlsZSwgaXNKU0RvY0NvbW1lbnRDb250YWluaW5nTm9kZSB9IGZyb20gXCJ0eXBlc2NyaXB0XCI7XG5cblxuaW50ZXJmYWNlIFJFUExJbnB1dFByb3BzIHtcbiAgaGlzdG9yeTogSlNYLkVsZW1lbnRbXTtcbiAgc2V0SGlzdG9yeTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248SlNYLkVsZW1lbnRbXT4+O1xufVxuXG5jb25zdCBzZWFyY2hMZW5ndGggPSA3O1xuY29uc3QgbG9hZExlbmd0aCA9IDEwOyAvLyB0cnVlIGZvciBicmllZiwgZmFsc2UgZm9yIHZlcmJvc2VcblxuZXhwb3J0IGZ1bmN0aW9uIFJFUExJbnB1dChwcm9wczogUkVQTElucHV0UHJvcHMpIHtcbiAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbZGF0YUxvYWRlZCwgc2V0RGF0YUxvYWRlZF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApOyAvLyAwIGlzIGRhdGEgbm90IGxvYWRlZCwgMSBpcyBkYXRhIGxvYWRlZFxuICBjb25zdCBbZGF0YSwgc2V0RGF0YV0gPSB1c2VTdGF0ZTxzdHJpbmdbXVtdIHwgdW5kZWZpbmVkPigpOyAvLyBjYWxsIHNldERhdGEgaW4gbG9hZGNzdiwgY2FsbCBkYXRhIGluIHZpZXcvc2VhcmNoP1xuICBjb25zdFtjc3ZGaWxlUGF0aCwgc2V0RmlsZVBhdGhdID0gdXNlU3RhdGU8U3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW2JyaWVmbW9kZSwgc2V0TW9kZV0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcblxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XG4gICAgey8qIEhBTkRMSU5HIENPTU1BTkQ6IG1vZGUgKi99XG4gICAgaWYgKGNvbW1hbmRTdHJpbmcgPT09IFwibW9kZVwiKSB7XG4gICAgICBzZXRNb2RlKCFicmllZm1vZGUpO1xuICAgICAgXG4gICAgICAgey8qIEhBTkRMSU5HIENPTU1BTkQ6IGxvYWRfZmlsZSAqL31cbiAgICB9IGVsc2UgaWYgKCBcbiAgICAgIGNvbW1hbmRTdHJpbmcubGVuZ3RoID49IGxvYWRMZW5ndGggJiZcbiAgICAgIGNvbW1hbmRTdHJpbmcuc3Vic3RyaW5nKDAsIGxvYWRMZW5ndGgpID09PSBcImxvYWRfZmlsZSBcIlxuICAgICkge1xuXG4gICAgICB2YXIgZmlsZVBhdGggPSBjb21tYW5kU3RyaW5nLnN1YnN0cmluZyhcbiAgICAgICAgbG9hZExlbmd0aCwgY29tbWFuZFN0cmluZy5sZW5ndGgpO1xuICAgICAgaWYgKGZpbGVwYXRoVG9QYXJzZWRDU1ZNYXAuaGFzKGZpbGVQYXRoKSkge1xuICAgICAgICBzZXREYXRhKGZpbGVwYXRoVG9QYXJzZWRDU1ZNYXAuZ2V0KGZpbGVQYXRoKSk7XG4gICAgICAgIHNldERhdGFMb2FkZWQoMSk7XG4gICAgICAgIHNldEZpbGVQYXRoKGZpbGVQYXRoKTtcbiAgICAgICAgbG9hZF9jc3Zfc3VjY2Vzcyhwcm9wcywgYnJpZWZtb2RlLCBjb21tYW5kU3RyaW5nKTtcblxuICAgICAgfSBlbHNlIHtsb2FkX2Nzdl9mYWlsKHByb3BzLCBicmllZm1vZGUsIGNvbW1hbmRTdHJpbmcpfVxuXG4gICAgICB7LyogSEFORExJTkcgQ09NTUFORDogdmlldyAqL31cbiAgICB9IGVsc2UgaWYgKGNvbW1hbmRTdHJpbmcgPT09IFwidmlld1wiICYmIGRhdGFMb2FkZWQgPT09IDApIHtcbiAgICAgIHZpZXdfZmFpbChwcm9wcywgYnJpZWZtb2RlLCBjb21tYW5kU3RyaW5nKTtcbiAgICB9IGVsc2UgaWYgKGNvbW1hbmRTdHJpbmcgPT09IFwidmlld1wiICYmIGRhdGFMb2FkZWQgPT09IDEpIHtcbiAgICAgIHZpZXdfc3VjY2Vzcyhwcm9wcywgY29tbWFuZFN0cmluZywgYnJpZWZtb2RlLCBkYXRhKTtcblxuICAgICAgey8qIEhBTkRMSU5HIENPTU1BTkQ6IHNlYXJjaCAqL31cbiAgICB9IGVsc2UgaWYgKFxuICAgICAgY29tbWFuZFN0cmluZy5sZW5ndGggPj0gc2VhcmNoTGVuZ3RoICYmXG4gICAgICBjb21tYW5kU3RyaW5nLnN1YnN0cmluZygwLCBzZWFyY2hMZW5ndGgpID09PSBcInNlYXJjaCBcIiAmJlxuICAgICAgZGF0YUxvYWRlZCA9PT0gMFxuICAgICkge3NlYXJjaF9ub3RfbG9hZGVkKHByb3BzLCBicmllZm1vZGUsIGNvbW1hbmRTdHJpbmcpO30gXG5cbiAgICBlbHNlIGlmIChcbiAgICAgIGNvbW1hbmRTdHJpbmcubGVuZ3RoID49IHNlYXJjaExlbmd0aCAmJlxuICAgICAgY29tbWFuZFN0cmluZy5zdWJzdHJpbmcoMCwgc2VhcmNoTGVuZ3RoKSA9PT0gXCJzZWFyY2ggXCIgJiZcbiAgICAgIGRhdGFMb2FkZWQgPT09IDFcbiAgICApIHtcbiAgICAgIHNlYXJjaF9sb2FkZWQocHJvcHMsIGJyaWVmbW9kZSwgY29tbWFuZFN0cmluZyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGVycm9yX21lc3NhZ2UocHJvcHMsIGJyaWVmbW9kZSwgY29tbWFuZFN0cmluZylcbiAgICB9XG5cbiAgICB7LyogVXBkYXRpbmcgU3VibWl0IEJ1dHRvbiAqL31cbiAgICBzZXRDb3VudChjb3VudCArIDEpO1xuICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XG4gIH1cbiAgXG4gIHsvKiBSRVRVUk5JTkcgUkVQTCBJTlBVVCBPVVRQVVQgKi99XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgICB7LyogTU9ERSBTVEFUVVMgJiBEQVRBIExPQUQgU1RBVFVTIEJBUlMgKi99XG4gICAgICAgIDxNb2RlU3RhdHVzIG1vZGU9e2JyaWVmbW9kZX0+PC9Nb2RlU3RhdHVzPlxuICAgICAgICA8TG9hZFN0YXR1cyBsb2FkU3RhdHVzPXtkYXRhTG9hZGVkfSBjc3ZGaWxlPXtjc3ZGaWxlUGF0aH0+PC9Mb2FkU3RhdHVzPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZSA9IFwiY29udGFpbmVyMVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZSA9IFwiaGlzdG9yeVwiPkNPTU1BTkRTPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIENPTU1BTkQgSU5QVVQgQkFSICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIyXCI+XG4gICAgICAgIDxDb250cm9sbGVkSW5wdXRcbiAgICAgICAgICB2YWx1ZT17Y29tbWFuZFN0cmluZ31cbiAgICAgICAgICBzZXRWYWx1ZT17c2V0Q29tbWFuZFN0cmluZ31cbiAgICAgICAgICBhcmlhTGFiZWw9e1wiQ29tbWFuZCBpbnB1dFwifVxuICAgICAgICAvPlxuICAgICAgICA8YnI+PC9icj5cblxuICAgICAgICB7LyogU1VCTUlUIEJVVFRPTiAqL31cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyl9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnV0dG9udGV4dFwiPlN1Ym1pdHRlZCB7Y291bnR9IHRpbWUocyk8L2Rpdj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICApO1xufVxuXG5mdW5jdGlvbiBsb2FkX2Nzdl9zdWNjZXNzKHByb3BzOiBSRVBMSW5wdXRQcm9wcywgYnJpZWZtb2RlOiBib29sZWFuLCBjb21tYW5kOiBzdHJpbmcpe1xuICBpZiAoYnJpZWZtb2RlKSB7XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAuLi5wcm9wcy5oaXN0b3J5LFxuICAgICAgPGRpdiBjbGFzc05hbWU9e1wic3VjY2Vzc1wifT5TdWNjZXNzZnVsbHkgbG9hZGVkIENTVjwvZGl2PixcbiAgICBdKTtcbiAgfSBlbHNlIHtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJjb21tYW5kXCJ9PkNvbW1hbmQ6IHtjb21tYW5kfTwvZGl2PixcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtcInN1Y2Nlc3NcIn0+T3V0cHV0OiBzdWNjZXNzZnVsbHkgbG9hZGVkIGNzdjwvZGl2PixcbiAgICBdKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBsb2FkX2Nzdl9mYWlsKHByb3BzOiBSRVBMSW5wdXRQcm9wcywgYnJpZWZtb2RlOiBib29sZWFuLCBjb21tYW5kOiBzdHJpbmcpe1xuICBpZiAoYnJpZWZtb2RlKSB7XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAuLi5wcm9wcy5oaXN0b3J5LCBcbiAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5mYWlsZWQgdG8gbG9hZCBjc3Y8L2Rpdj5dKTtcbiAgfSBlbHNlIHtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJjb21tYW5kXCJ9PkNvbW1hbmQ6IHtjb21tYW5kfTwvZGl2PixcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtcImVycm9yXCJ9Pk91dHB1dDogZmFpbGVkIHRvIGxvYWQgY3N2PC9kaXY+LFxuICAgIF0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIHZpZXdfZmFpbChwcm9wczogUkVQTElucHV0UHJvcHMsIGJyaWVmbW9kZTogYm9vbGVhbiwgY29tbWFuZDogc3RyaW5nKXtcbiAgaWYgKGJyaWVmbW9kZSkge1xuICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIDxkaXYgY2xhc3NOYW1lPXtcImVycm9yXCJ9PmRhdGEgbm90IGxvYWRlZDwvZGl2Pl0pO1xuICB9IGVsc2Uge1xuICAgIHByb3BzLnNldEhpc3RvcnkoW1xuICAgICAgLi4ucHJvcHMuaGlzdG9yeSxcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtcImNvbW1hbmRcIn0+Q29tbWFuZDoge2NvbW1hbmR9PC9kaXY+LFxuICAgICAgPGRpdiBjbGFzc05hbWU9e1wiZXJyb3JcIn0+T3V0cHV0OiBkYXRhIG5vdCBsb2FkZWQ8L2Rpdj4sXG4gIF0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIHZpZXdfc3VjY2Vzcyhwcm9wczogUkVQTElucHV0UHJvcHMsIGNvbW1hbmQ6IHN0cmluZywgYnJpZWZtb2RlOiBib29sZWFuLCBkYXRhOiBzdHJpbmdbXVtdIHwgdW5kZWZpbmVkKXtcbiAgaWYgKGJyaWVmbW9kZSkge1xuICAgIHByb3BzLnNldEhpc3RvcnkoW1xuICAgICAgLi4ucHJvcHMuaGlzdG9yeSxcbiAgICAgIDxEYXRhVGFibGUgZGF0YT17ZGF0YX0+PC9EYXRhVGFibGU+XG4gICAgXSk7XG4gIH0gZWxzZSB7XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAuLi5wcm9wcy5oaXN0b3J5LFxuICAgICAgPGRpdiBjbGFzc05hbWUgPSBcImNvbW1hbmRcIj5Db21tYW5kOiB7Y29tbWFuZH08L2Rpdj4sXG4gICAgICA8RGF0YVRhYmxlIGRhdGE9e2RhdGF9PjwvRGF0YVRhYmxlPlxuICAgIF0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVycm9yX21lc3NhZ2UocHJvcHM6IFJFUExJbnB1dFByb3BzLCBicmllZm1vZGU6IGJvb2xlYW4sIGNvbW1hbmQ6IHN0cmluZyl7XG4gIGlmIChicmllZm1vZGUpIHtcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5JbnZhbGlkIGNvbW1hbmQgb3IgYXJndW1lbnRzPC9kaXY+LFxuICAgIF0pO1xuICB9IGVsc2Uge1xuICAgIHByb3BzLnNldEhpc3RvcnkoW1xuICAgICAgLi4ucHJvcHMuaGlzdG9yeSxcbiAgICAgIDxkaXYgY2xhc3NOYW1lPSB7XCJjb21tYW5kXCJ9PkNvbW1hbmQ6IHtjb21tYW5kfTwvZGl2PixcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtcImVycm9yXCJ9Pk91dHB1dDogSW52YWxpZCBjb21tYW5kIG9yIGFyZ3VtZW50czwvZGl2PixcbiAgICBdKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzZWFyY2hfbm90X2xvYWRlZChwcm9wczogUkVQTElucHV0UHJvcHMsIGJyaWVmbW9kZTogYm9vbGVhbiwgY29tbWFuZDogc3RyaW5nKXtcbiAgaWYgKGJyaWVmbW9kZSkge1xuICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIDxkaXY+ZGF0YSBub3QgbG9hZGVkPC9kaXY+XSk7XG4gIH0gZWxzZSB7XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAuLi5wcm9wcy5oaXN0b3J5LFxuICAgICAgPGRpdiBjbGFzc05hbWU9e1wiY29tbWFuZFwifT5Db21tYW5kOiB7Y29tbWFuZH08L2Rpdj4sXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17XCJlcnJvclwifT5PdXRwdXQ6IGRhdGEgbm90IGxvYWRlZDwvZGl2PixcbiAgICBdKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzZWFyY2hfbG9hZGVkKHByb3BzOiBSRVBMSW5wdXRQcm9wcywgYnJpZWZtb2RlOiBib29sZWFuLCBjb21tYW5kOiBzdHJpbmcpe1xuICB2YXIgc2VhcmNoU3RyaW5nID0gY29tbWFuZC5zdWJzdHJpbmcoc2VhcmNoTGVuZ3RoLCBjb21tYW5kLmxlbmd0aCk7XG4gIHZhciB2YWxpZEFyZ3VtZW50cyA9IGNvbW1hbmQuc3Vic3RyaW5nKHNlYXJjaExlbmd0aCwgY29tbWFuZC5sZW5ndGgpLmluY2x1ZGVzKFwiIFwiKTtcbiAgdmFyIHNlYXJjaFZhbGlkID0gcXVlcnlUb1NlYXJjaGVkQ1NWTWFwLmhhcyhzZWFyY2hTdHJpbmcpO1xuXG4gIGlmICh2YWxpZEFyZ3VtZW50cyl7XG5cbiAgICBpZiAoc2VhcmNoVmFsaWQpe1xuXG4gICAgICBpZiAoYnJpZWZtb2RlKXtcbiAgICAgICAgdmFyIGRhdGEgPSBxdWVyeVRvU2VhcmNoZWRDU1ZNYXAuZ2V0KHNlYXJjaFN0cmluZyk7XG4gICAgICAgIHByb3BzLnNldEhpc3RvcnkoW1xuICAgICAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICAgICAgPERhdGFUYWJsZSBkYXRhPXtkYXRhfT48L0RhdGFUYWJsZT5cbiAgICAgICAgXSk7XG4gICAgICB9XG5cbiAgICAgIGlmICghYnJpZWZtb2RlKSB7XG4gICAgICAgIHZhciBkYXRhID0gcXVlcnlUb1NlYXJjaGVkQ1NWTWFwLmdldChzZWFyY2hTdHJpbmcpO1xuICAgICAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgICAgICAuLi5wcm9wcy5oaXN0b3J5LFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lID0gXCJjb21tYW5kXCI+Q29tbWFuZDoge2NvbW1hbmR9PC9kaXY+LFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lID0gXCJzdWNjZXNzXCI+T3V0cHV0OjwvZGl2PixcbiAgICAgICAgICA8RGF0YVRhYmxlIGRhdGE9e2RhdGF9PjwvRGF0YVRhYmxlPlxuICAgICAgICBdKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoIXNlYXJjaFZhbGlkKXtcbiAgICAgIGlmIChicmllZm1vZGUpe1xuICAgICAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgICAgICAuLi5wcm9wcy5oaXN0b3J5LFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lID0gXCJlcnJvclwiPkludmFsaWQgc2VhcmNoPC9kaXY+XG4gICAgICAgIF0pO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWJyaWVmbW9kZSl7XG4gICAgICAgIHByb3BzLnNldEhpc3RvcnkoW1xuICAgICAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWUgPSBcImNvbW1hbmRcIj5Db21tYW5kOiB7Y29tbWFuZH08L2Rpdj4sXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWUgPSBcImVycm9yXCI+SW52YWxpZCBzZWFyY2g8L2Rpdj5cbiAgICAgICAgXSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaWYgKCF2YWxpZEFyZ3VtZW50cyl7XG4gICAgaWYgKGJyaWVmbW9kZSl7XG4gICAgICBwcm9wcy5zZXRIaXN0b3J5KFtcbiAgICAgICAgLi4ucHJvcHMuaGlzdG9yeSxcbiAgICAgICAgPGRpdiBjbGFzc05hbWUgPSBcImVycm9yXCI+SW52YWxpZCBudW1iZXIgb2YgYXJndW1lbnRzPC9kaXY+XG4gICAgICBdKTtcbiAgICB9XG5cbiAgICBpZiAoIWJyaWVmbW9kZSkge1xuICAgICAgcHJvcHMuc2V0SGlzdG9yeShbXG4gICAgICAgIC4uLnByb3BzLmhpc3RvcnksXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lID0gXCJjb21tYW5kXCI+Q29tbWFuZDoge2NvbW1hbmR9PC9kaXY+LFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZSA9IFwiZXJyb3JcIj5JbnZhbGlkIG51bWJlciBvZiBhcmd1bWVudHM8L2Rpdj5cbiAgICAgIF0pO1xuICAgIH1cbiAgfVxufSJdLCJmaWxlIjoiL1VzZXJzL21pY2hlbGxlZGluZy9EZXNrdG9wL0NTMzJBc3NpZ25tZW50cy9tb2NrLWF6aG91NzYtbWRpbmcxNi9zcmMvY29tcG9uZW50cy9SRVBMSW5wdXQudHN4In0=