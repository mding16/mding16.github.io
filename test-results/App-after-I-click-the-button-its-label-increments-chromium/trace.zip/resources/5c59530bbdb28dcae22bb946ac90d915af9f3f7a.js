import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MiscComponents/DataTable.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0a4e3deb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/MiscComponents/DataTable.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function DataTable(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "tablecontainer", children: /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tbody", { children: props.data.map((rowContent, rowID) => /* @__PURE__ */ jsxDEV("tr", { children: rowContent.map((val, rowID2) => /* @__PURE__ */ jsxDEV("td", { children: val }, rowID2, false, {
    fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/MiscComponents/DataTable.tsx",
    lineNumber: 9,
    columnNumber: 45
  }, this)) }, void 0, false, {
    fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/MiscComponents/DataTable.tsx",
    lineNumber: 8,
    columnNumber: 49
  }, this)) }, void 0, false, {
    fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/MiscComponents/DataTable.tsx",
    lineNumber: 7,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/MiscComponents/DataTable.tsx",
    lineNumber: 6,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/MiscComponents/DataTable.tsx",
    lineNumber: 5,
    columnNumber: 10
  }, this);
}
_c = DataTable;
var _c;
$RefreshReg$(_c, "DataTable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/MiscComponents/DataTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV2M7QUFYZCwyQkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSWxCLGdCQUFTQSxVQUFVQyxPQUFzQjtBQUM1QyxTQUFPLHVCQUFDLFNBQUksV0FBWSxrQkFDeEIsaUNBQUMsV0FDQyxpQ0FBQyxXQUNFQSxnQkFBTUMsS0FBTUMsSUFBSSxDQUFDQyxZQUFZQyxVQUM1Qix1QkFBQyxRQUNFRCxxQkFBV0QsSUFBSSxDQUFDRyxLQUFLRCxXQUNwQix1QkFBQyxRQUFnQkMsaUJBQVJELFFBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxQixDQUN0QixLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQSxDQUNELEtBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBLEtBWE87QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlQO0FBQ0o7QUFBQ0UsS0FkZVA7QUFBUyxJQUFBTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRGF0YVRhYmxlIiwicHJvcHMiLCJkYXRhIiwibWFwIiwicm93Q29udGVudCIsInJvd0lEIiwidmFsIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEYXRhVGFibGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImludGVyZmFjZSBEYXRhVGFibGVQcm9wcyB7XG4gICAgZGF0YTogc3RyaW5nW11bXSB8IHVuZGVmaW5lZFxuICB9XG5cbmV4cG9ydCBmdW5jdGlvbiBEYXRhVGFibGUocHJvcHM6IERhdGFUYWJsZVByb3BzKXtcbiAgICByZXR1cm4oPGRpdiBjbGFzc05hbWUgPSBcInRhYmxlY29udGFpbmVyXCI+XG4gICAgPHRhYmxlPlxuICAgICAgPHRib2R5PlxuICAgICAgICB7cHJvcHMuZGF0YSEubWFwKChyb3dDb250ZW50LCByb3dJRCkgPT4gKFxuICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgIHtyb3dDb250ZW50Lm1hcCgodmFsLCByb3dJRCkgPT4gKFxuICAgICAgICAgICAgICA8dGQga2V5PXtyb3dJRH0+e3ZhbH08L3RkPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC90cj5cbiAgICAgICAgKSl9XG4gICAgICA8L3Rib2R5PlxuICAgIDwvdGFibGU+XG4gICAgPC9kaXY+KVxufSJdLCJmaWxlIjoiL1VzZXJzL2FsZXhhbmRlcnpob3UvRGVza3RvcC9jczMyL21vY2stYXpob3U3Ni1tZGluZzE2L3NyYy9jb21wb25lbnRzL01pc2NDb21wb25lbnRzL0RhdGFUYWJsZS50c3gifQ==