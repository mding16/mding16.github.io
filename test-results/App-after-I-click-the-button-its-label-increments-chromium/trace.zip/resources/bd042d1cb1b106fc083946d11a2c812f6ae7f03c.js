import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0a4e3deb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function REPLHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "container", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "command-box", children: [
      "VALID COMMANDS:",
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx",
        lineNumber: 10,
        columnNumber: 9
      }, this),
      'load_file "filepath"',
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx",
        lineNumber: 12,
        columnNumber: 9
      }, this),
      "view",
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx",
        lineNumber: 14,
        columnNumber: 9
      }, this),
      'search "identifier" "tosearch"',
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx",
        lineNumber: 16,
        columnNumber: 9
      }, this),
      "mode",
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx",
      lineNumber: 8,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: props.history.map((value) => /* @__PURE__ */ jsxDEV("div", { children: value }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx",
      lineNumber: 23,
      columnNumber: 37
    }, this)) }, void 0, false, {
      fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/alexanderzhou/Desktop/cs32/mock-azhou76-mding16/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1E7QUFYUiwyQkFBc0I7QUFBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQy9CLE9BQU87QUFLQSxnQkFBU0EsWUFBWUMsT0FBeUI7QUFDbkQsU0FDRSx1QkFBQyxTQUFJLFdBQVksYUFDZjtBQUFBLDJCQUFDLFNBQUksV0FBWSxlQUFhO0FBQUE7QUFBQSxNQUU1Qix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBSTtBQUFBLE1BQUk7QUFBQSxNQUVSLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFJO0FBQUEsTUFBSTtBQUFBLE1BRVIsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUk7QUFBQSxNQUFJO0FBQUEsTUFFUix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBSTtBQUFBLE1BQUk7QUFBQSxNQUVSLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFJO0FBQUEsU0FWTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFHWkEsZ0JBQU1DLFFBQVFDLElBQUtDLFdBQVUsdUJBQUMsU0FBS0EsbUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZLENBQU0sS0FIbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUNBO0FBQUNDLEtBckJXTDtBQUFXLElBQUFLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSRVBMSGlzdG9yeSIsInByb3BzIiwiaGlzdG9yeSIsIm1hcCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSGlzdG9yeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY2xlYXIgfSBmcm9tIFwiY29uc29sZVwiO1xuaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5cbmludGVyZmFjZSBSRVBMSGlzdG9yeVByb3BzIHtcbiAgaGlzdG9yeTogSlNYLkVsZW1lbnRbXTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBSRVBMSGlzdG9yeShwcm9wczogUkVQTEhpc3RvcnlQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lID0gXCJjb250YWluZXJcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lID0gXCJjb21tYW5kLWJveFwiPlxuICAgICAgIFZBTElEIENPTU1BTkRTOlxuICAgICAgICA8aHI+PC9ocj5cbiAgICAgICAgbG9hZF9maWxlIFwiZmlsZXBhdGhcIlxuICAgICAgICA8aHI+PC9ocj5cbiAgICAgICAgdmlld1xuICAgICAgICA8aHI+PC9ocj5cbiAgICAgICAgc2VhcmNoIFwiaWRlbnRpZmllclwiIFwidG9zZWFyY2hcIlxuICAgICAgICA8aHI+PC9ocj5cbiAgICAgICAgbW9kZVxuICAgICAgICA8aHI+PC9ocj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWhpc3RvcnlcIj5cbiAgICAgIHsvKiBUaGlzIGlzIHdoZXJlIGNvbW1hbmQgaGlzdG9yeSB3aWxsIGdvICovfVxuICAgICAgey8qIFRPRE86IFRvIGdvIHRocm91Z2ggYWxsIHRoZSBwdXNoZWQgY29tbWFuZHMuLi4gdHJ5IHRoZSAubWFwKCkgZnVuY3Rpb24hICovfVxuICAgICAgICB7cHJvcHMuaGlzdG9yeS5tYXAoKHZhbHVlKSA9PiA8ZGl2Pnt2YWx1ZX08L2Rpdj4pfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7fVxuXG4iXSwiZmlsZSI6Ii9Vc2Vycy9hbGV4YW5kZXJ6aG91L0Rlc2t0b3AvY3MzMi9tb2NrLWF6aG91NzYtbWRpbmcxNi9zcmMvY29tcG9uZW50cy9SRVBMSGlzdG9yeS50c3gifQ==